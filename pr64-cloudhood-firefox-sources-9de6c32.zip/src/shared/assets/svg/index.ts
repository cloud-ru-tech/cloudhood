export { DragIndicatorSVG } from './DragIndicator';
export { EditSVG } from './Edit';
export { FileOpenSVG } from './FileOpen';
export { PauseSVG } from './Pause';
export { PlayArrowSVG } from './PlayArrow';
export { SwitchAccountSVG } from './SwitchAccount';
export { FileUploadSVG } from './FileUpload';
