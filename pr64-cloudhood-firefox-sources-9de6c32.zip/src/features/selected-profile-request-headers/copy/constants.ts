export enum COPY_RESULT_STATUS {
  Success = 'Copied request header to clipboard.',
  Error = 'Failed to copy request header.',
}
