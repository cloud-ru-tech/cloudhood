export enum REMOVE_ALL_URL_FILTERS_RESULT_STATUS {
  Success = 'All URL filters removed successfully.',
  Error = 'Failed to remove URL filters.',
}
