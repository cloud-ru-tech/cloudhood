import { SVGProps } from 'react';

export function PauseSVG(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns='http://www.w3.org/2000/svg'
      height='20px'
      viewBox='0 -960 960 960'
      width='20px'
      fill='currentColor'
      {...props}
    >
      <path d='M520-200v-560h240v560H520Zm-320 0v-560h240v560H200Zm400-80h80v-400h-80v400Zm-320 0h80v-400h-80v400Zm0-400v400-400Zm320 0v400-400Z' />
    </svg>
  );
}
