// eslint-disable-next-line @typescript-eslint/no-var-requires
const config = require('@cloud-ru/ft-config-stylelint');

module.exports = config;
