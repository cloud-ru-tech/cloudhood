import { CSSProperties, JSXElementConstructor } from 'react';

type SvgIconProps = {
  style?: CSSProperties;
  className?: string;
};

type MuiIconProps = {
  icon: JSXElementConstructor<SvgIconProps>;
} & SvgIconProps;

export function MuiIcon({ icon: Icon, ...rest }: MuiIconProps) {
  return <Icon {...rest} className={`mui-icon ${rest.className || ''}`} />;
}
