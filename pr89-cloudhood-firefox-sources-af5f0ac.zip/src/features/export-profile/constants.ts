export enum COPY_RESULT_STATUS {
  Success = 'Copied exported profiles to clipboard.',
  Error = 'Failed to copy exported profiles.',
}
