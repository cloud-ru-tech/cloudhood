import styled from '@emotion/styled';

import { themeVars } from '@snack-uikit/figma-tokens';

export const Ul = styled.ul``;

export const Li = styled.li`
  ${themeVars.sans.body.m};
`;
