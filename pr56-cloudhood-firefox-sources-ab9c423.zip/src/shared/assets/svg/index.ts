import DragIndicatorSVG from './DragIndicator.svg';
import EditSVG from './Edit.svg';
import FileOpenSVG from './FileOpen.svg';
import PauseSVG from './Pause.svg';
import PlayArrowSVG from './PlayArrow.svg';
import SwitchAccountSVG from './SwitchAccount.svg';

export { DragIndicatorSVG, EditSVG, PauseSVG, PlayArrowSVG, SwitchAccountSVG, FileOpenSVG };
