import browser from 'webextension-polyfill';

import type { Profile, RequestHeader } from '#entities/request-profile/types';

import { BrowserStorageKey, RuntimeMessageType } from './shared/constants';
import { validateCookie } from './shared/utils/cookies';
import { countActiveHeadersForUrl, doesUrlMatchFilter } from './shared/utils/countActiveHeadersForUrl';
import {
  filterDebugLogsForProfile,
  parseProfileFromUnknown,
  parseProfilesFromStorage,
} from './shared/utils/debugLogsExport';
import { validateHeader } from './shared/utils/headers';
import { logger, LogLevel } from './shared/utils/logger';
import { setBrowserCookies } from './shared/utils/setBrowserCookies';
import { setBrowserHeaders } from './shared/utils/setBrowserHeaders';
import { setIconBadge } from './shared/utils/setIconBadge';
import { enableExtensionReload } from './utils/extension-reload';

logger.configure({
  minLevel: process.env.NODE_ENV === 'development' ? LogLevel.DEBUG : LogLevel.INFO,
  showTimestamp: true,
  enabled: true,
});

// Simple check to verify background script execution
logger.info('🎯 Background script loaded successfully!');
// Duplicate in logger.debug to ensure visibility
logger.debug('🎯 Background script loaded successfully! (debug)');
logger.info('🔍 About to check storage contents...');

async function getCurrentTabUrl(): Promise<string | undefined> {
  try {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    return tabs[0]?.url;
  } catch {
    return undefined;
  }
}

// Check storage immediately on background script load
(async () => {
  try {
    const result = await browser.storage.local.get([
      BrowserStorageKey.Profiles,
      BrowserStorageKey.SelectedProfile,
      BrowserStorageKey.IsPaused,
    ]);

    logger.group('📦 Storage contents on background script load:', true);
    logger.info('  - Profiles:', result[BrowserStorageKey.Profiles] ? 'Present' : 'Missing');
    logger.info('  - Selected Profile:', result[BrowserStorageKey.SelectedProfile] || 'None');
    logger.info('  - Is Paused:', result[BrowserStorageKey.IsPaused] || false);

    // Log profile count if present
    let activeHeadersCount = 0;
    if (result[BrowserStorageKey.Profiles]) {
      try {
        const profiles = JSON.parse(result[BrowserStorageKey.Profiles] as string);
        logger.info(`  - Profiles count: ${profiles.length}`);
        if (profiles.length > 0) {
          logger.info('  - Profile names:', profiles.map((p: Profile) => p.name || p.id).join(', '));

          // Count active headers for the badge
          const selectedProfile = profiles.find((p: Profile) => p.id === result[BrowserStorageKey.SelectedProfile]);
          if (selectedProfile) {
            activeHeadersCount = selectedProfile.requestHeaders?.filter((h: RequestHeader) => !h.disabled).length || 0;
            logger.info(`  - Active headers count: ${activeHeadersCount}`);
          }
        }
      } catch (error) {
        logger.warn('  - Failed to parse profiles:', error);
      }
    }

    logger.debug('Background script load storage data:', JSON.stringify(result, null, 2));
    logger.groupEnd();

    // DNR mutations are deliberately performed only by applyHeadersFromStorageQueue.
    // sw-init below owns the queue during worker startup, so a direct update here
    // could race with its stale-rule cleanup on slower machines (notably Windows).
    logger.info('🏷️ Initial DNR sync is scheduled by sw-init queue');
  } catch (error) {
    logger.error('Failed to check storage on background script load:', error);
  }
})();

// Initialize auto-reload only in development mode
if (process.env.NODE_ENV === 'development') {
  enableExtensionReload();
  logger.debug('Extension auto-reload enabled for development mode');
}

const MAX_DEBUG_LOGS = 3000;

const workerBootId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
const workerBootAt = Date.now();
let debugLogSeq = 0;
const debugLogsBuffer: Array<{ seq: number; timestamp: number; level: string; message: string; args: string[] }> = [];

let applyInProgress = false;
let applyPending = false;
let applyCounter = 0;
let lastRequestedReason = 'unknown';
let lastAppliedStorageFingerprint: string | null = null;
let lastAppliedMeta: { seq: number; updatedAt: number } = { seq: 0, updatedAt: 0 };

function safeStringify(value: unknown): string {
  const seen = new WeakSet<object>();
  return JSON.stringify(
    value,
    (_, currentValue) => {
      if (currentValue instanceof Error) {
        return {
          name: currentValue.name,
          message: currentValue.message,
          stack: currentValue.stack,
        };
      }
      if (currentValue && typeof currentValue === 'object') {
        if (seen.has(currentValue as object)) {
          return '[Circular]';
        }
        seen.add(currentValue as object);
      }
      return currentValue;
    },
    2,
  );
}

function appendDebugLog(entry: { timestamp: number; level: string; message: string; args: string[] }): void {
  debugLogSeq += 1;
  debugLogsBuffer.push({ seq: debugLogSeq, ...entry });
  if (debugLogsBuffer.length > MAX_DEBUG_LOGS) {
    debugLogsBuffer.splice(0, debugLogsBuffer.length - MAX_DEBUG_LOGS);
  }
}

logger.setExternalSink(({ level, message, args, timestamp }) => {
  const serializedArgs = args.map(item => safeStringify(item));
  appendDebugLog({ timestamp, level, message, args: serializedArgs });
});

function getApplyHealthSnapshot() {
  const now = Date.now();
  return {
    workerBootId,
    workerUptimeMs: now - workerBootAt,
    applyInProgress,
    applyPending,
    applyCounter,
    lastRequestedReason,
    lastAppliedStorageFingerprint,
    lastAppliedMeta,
  };
}

async function buildDebugLogsExportPayload(options?: { profileId?: string; profile?: unknown }) {
  const now = Date.now();
  const storage = await browser.storage.local.get([
    BrowserStorageKey.Profiles,
    BrowserStorageKey.SelectedProfile,
    BrowserStorageKey.IsPaused,
    BrowserStorageKey.HeadersConfigMeta,
  ]);

  let dynamicRules: unknown[] = [];
  let sessionRules: unknown[] = [];
  try {
    dynamicRules = await browser.declarativeNetRequest.getDynamicRules();
  } catch {
    dynamicRules = [];
  }
  try {
    sessionRules = await browser.declarativeNetRequest.getSessionRules();
  } catch {
    sessionRules = [];
  }

  const payload = {
    exportedAt: new Date(now).toISOString(),
    scope: 'general' as const,
    worker: {
      bootId: workerBootId,
      bootedAt: new Date(workerBootAt).toISOString(),
      uptimeMs: now - workerBootAt,
    },
    health: getApplyHealthSnapshot(),
    storage,
    dnr: {
      dynamicRulesCount: dynamicRules.length,
      sessionRulesCount: sessionRules.length,
      dynamicRules,
      sessionRules,
    },
    logs: debugLogsBuffer,
  };

  if (!options) {
    return payload;
  }

  const profileId = options.profileId;
  const profile =
    parseProfileFromUnknown(options.profile) ?? parseProfilesFromStorage(storage).find(item => item.id === profileId);

  if (!profile) {
    throw new Error(`Profile "${profileId ?? ''}" not found`);
  }

  return filterDebugLogsForProfile(payload, profile);
}

function storageFingerprint(result: Record<string, unknown>): string {
  const profiles = result[BrowserStorageKey.Profiles];
  const selected = result[BrowserStorageKey.SelectedProfile];
  const paused = result[BrowserStorageKey.IsPaused];

  // Keep it cheap and stable: correlate across logs without huge payloads.
  // If profiles is a big JSON string, we don't want to log it fully.
  let profilesStr = '';
  if (typeof profiles === 'string') {
    profilesStr = profiles;
  } else if (profiles !== undefined) {
    profilesStr = JSON.stringify(profiles);
  }
  const selectedStr = typeof selected === 'string' ? selected : String(selected ?? '');
  const pausedStr = paused === undefined ? '' : String(Boolean(paused));

  // Simple FNV-1a 32-bit hash for correlation (no deps).
  const input = `${selectedStr}|${pausedStr}|${profilesStr}`;
  let hash = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);

    hash = (hash * 0x01000193) >>> 0;
  }
  return `fnv1a32:${hash.toString(16)}:len:${input.length}`;
}

function normalizeHeadersConfigMeta(value: unknown): { seq: number; updatedAt: number } {
  if (value && typeof value === 'object') {
    const obj = value as Record<string, unknown>;
    const seq = typeof obj.seq === 'number' && Number.isFinite(obj.seq) ? obj.seq : 0;
    const updatedAt = typeof obj.updatedAt === 'number' && Number.isFinite(obj.updatedAt) ? obj.updatedAt : 0;
    return { seq, updatedAt };
  }
  if (typeof value === 'string') {
    try {
      return normalizeHeadersConfigMeta(JSON.parse(value) as unknown);
    } catch {
      return { seq: 0, updatedAt: 0 };
    }
  }
  return { seq: 0, updatedAt: 0 };
}

function isNewerMeta(next: { seq: number; updatedAt: number }, prev: { seq: number; updatedAt: number }) {
  if (next.seq !== prev.seq) return next.seq > prev.seq;
  return next.updatedAt > prev.updatedAt;
}

/**
 * Refreshes the badge for the active tab without touching DNR rules.
 *
 * Tab activation/navigation used to call setBrowserHeaders directly just to refresh
 * the badge. That bypassed the apply queue and could overlap with a storage-driven
 * DNR update or the sw-init stale-rule cleanup.
 */
async function refreshBadgeFromStorage(result: Record<string, unknown>, currentTabUrl: string | undefined) {
  const isPaused = result[BrowserStorageKey.IsPaused] === true;
  let profiles: Profile[] = [];

  try {
    const profilesData = result[BrowserStorageKey.Profiles];
    if (typeof profilesData === 'string') {
      profiles = JSON.parse(profilesData) as Profile[];
    } else if (Array.isArray(profilesData)) {
      profiles = profilesData as Profile[];
    }
  } catch (error) {
    logger.warn('Failed to parse profiles while refreshing badge:', error);
  }

  const selectedProfileId = result[BrowserStorageKey.SelectedProfile];
  const selectedProfile =
    profiles.find(profile => profile.id === selectedProfileId) ?? (profiles.length > 0 ? profiles[0] : undefined);
  const activeHeaders = (selectedProfile?.requestHeaders ?? []).filter(
    ({ disabled, name, value }) => !disabled && validateHeader(name, value),
  );
  const activeUrlFilters = (selectedProfile?.urlFilters ?? [])
    .filter(({ disabled, value }) => !disabled && value.trim())
    .map(({ value }) => value.trim());
  const activeCookies = (selectedProfile?.requestCookies ?? []).filter(
    ({ disabled, name, value }) => !disabled && validateCookie(name, value),
  );
  const urlMatchesCurrentTab =
    activeUrlFilters.length === 0 ||
    !currentTabUrl ||
    activeUrlFilters.some(filter => doesUrlMatchFilter(currentTabUrl, filter));
  const activeRulesCount =
    countActiveHeadersForUrl(activeHeaders, activeUrlFilters, currentTabUrl) +
    (urlMatchesCurrentTab ? activeCookies.length : 0);

  await setIconBadge({ isPaused, activeRulesCount });
}

async function applyHeadersFromStorageQueue(reason: string) {
  lastRequestedReason = reason;
  applyPending = true;

  logger.debug('📥 applyHeadersFromStorageQueue called:', {
    reason,
    applyInProgress,
    applyPending,
    lastAppliedStorageFingerprint,
    lastAppliedMeta,
  });

  if (applyInProgress) {
    logger.debug('⏳ Apply already in progress, queued for later');
    return;
  }
  applyInProgress = true;
  logger.debug('🔒 Apply lock acquired');

  try {
    while (applyPending) {
      applyPending = false;
      const applyId = ++applyCounter;

      const startedAt = Date.now();
      const result = await browser.storage.local.get([
        BrowserStorageKey.Profiles,
        BrowserStorageKey.SelectedProfile,
        BrowserStorageKey.IsPaused,
        BrowserStorageKey.HeadersConfigMeta,
      ]);
      const fp = storageFingerprint(result);
      const meta = normalizeHeadersConfigMeta(result[BrowserStorageKey.HeadersConfigMeta]);

      logger.group('🧵 Headers apply (queued)', true);
      logger.info('Apply request:', {
        applyId,
        reason: lastRequestedReason,
        startedAt,
        elapsedMsBeforeApply: Date.now() - startedAt,
        storageFingerprint: fp,
        headersConfigMeta: meta,
        lastAppliedMeta,
      });

      try {
        const isNewer = isNewerMeta(meta, lastAppliedMeta);
        const isSameFingerprint = lastAppliedStorageFingerprint === fp;

        logger.debug('🔍 Apply decision check:', {
          applyId,
          isNewerMeta: isNewer,
          isSameFingerprint,
          meta,
          lastAppliedMeta,
          fp,
          lastAppliedStorageFingerprint,
        });

        // On the first worker run old installations may not yet have config meta.
        // The fingerprint still proves there is an unapplied configuration, so do
        // not leave its valid headers absent just because meta is { seq: 0 }.
        if (!isNewer && lastAppliedStorageFingerprint !== null) {
          logger.warn('⏭️ Apply skipped (stale meta):', {
            applyId,
            reason: `meta.seq=${meta.seq} <= lastApplied.seq=${lastAppliedMeta.seq}, meta.updatedAt=${meta.updatedAt} <= lastApplied.updatedAt=${lastAppliedMeta.updatedAt}`,
            headersConfigMeta: meta,
            lastAppliedMeta,
          });
          continue;
        }
        if (isSameFingerprint) {
          // Meta changed but effective config didn't. Still advance meta to avoid replaying.
          const prevMeta = { ...lastAppliedMeta };
          lastAppliedMeta = meta;
          logger.info('⏭️ Apply skipped (no effective changes):', {
            applyId,
            storageFingerprint: fp,
            headersConfigMeta: meta,
            prevMeta,
            note: 'Meta advanced to prevent replay',
          });
        } else {
          const prevFp = lastAppliedStorageFingerprint;
          const prevMeta = { ...lastAppliedMeta };
          const currentTabUrl = await getCurrentTabUrl();

          const [{ stuckRuleIds }] = await Promise.all([
            setBrowserHeaders(result, {
              applyId,
              reason: lastRequestedReason,
              storageFingerprint: fp,
              currentTabUrl,
            }),
            setBrowserCookies(result),
          ]);
          await browser.storage.local.set({
            [BrowserStorageKey.DnrHealth]: { ok: stuckRuleIds.length === 0, stuckRuleIds, updatedAt: Date.now() },
          });

          lastAppliedStorageFingerprint = fp;
          lastAppliedMeta = meta;

          logger.info('✅ Apply done:', {
            applyId,
            elapsedMsTotal: Date.now() - startedAt,
            fingerprintChange: `${prevFp} → ${fp}`,
            metaChange: `seq:${prevMeta.seq}→${meta.seq}, updatedAt:${prevMeta.updatedAt}→${meta.updatedAt}`,
          });
        }
      } catch (error) {
        logger.error('❌ Apply failed (state NOT updated, will retry on next change):', {
          applyId,
          error,
          stateRemains: {
            lastAppliedStorageFingerprint,
            lastAppliedMeta,
          },
          attemptedFingerprint: fp,
          attemptedMeta: meta,
        });
      } finally {
        logger.groupEnd();
      }
    }
  } finally {
    applyInProgress = false;
    logger.debug('🔓 Apply lock released:', {
      lastAppliedStorageFingerprint,
      lastAppliedMeta,
    });
  }
}

browser.runtime.onStartup.addListener(async function () {
  logger.info('Extension startup triggered');

  const result = await browser.storage.local.get([
    BrowserStorageKey.Profiles,
    BrowserStorageKey.SelectedProfile,
    BrowserStorageKey.IsPaused,
    BrowserStorageKey.HeadersConfigMeta,
  ]);

  // Detailed logging of storage contents on startup
  logger.info('📦 Storage contents on startup:');
  logger.info('  - Profiles:', result[BrowserStorageKey.Profiles] ? 'Present' : 'Missing');
  logger.info('  - Selected Profile:', result[BrowserStorageKey.SelectedProfile] || 'None');
  logger.info('  - Is Paused:', result[BrowserStorageKey.IsPaused] || false);
  logger.debug('Startup storage data:', JSON.stringify(result, null, 2));

  // Log profile count if present
  if (result[BrowserStorageKey.Profiles]) {
    try {
      const profiles = JSON.parse(result[BrowserStorageKey.Profiles] as string);
      logger.info(`  - Profiles count: ${profiles.length}`);
      if (profiles.length > 0) {
        logger.info('  - Profile names:', profiles.map((p: Profile) => p.name || p.id).join(', '));
      }
    } catch (error) {
      logger.warn('  - Failed to parse profiles:', error);
    }
  }

  logger.debug('Startup storage data:', result);

  if (Object.keys(result).length) {
    logger.info('🚀 Storage data found, setting browser headers on startup');
    await applyHeadersFromStorageQueue('runtime.onStartup');
  } else {
    logger.info('📭 No storage data found on startup - extension will start with default settings');
  }
});

browser.runtime.onMessage.addListener((message: unknown) => {
  if (!message || typeof message !== 'object') return undefined;
  const payload = message as { type?: string; scope?: unknown; profileId?: unknown; profile?: unknown };
  if (payload.type !== RuntimeMessageType.ExportDebugLogs) return undefined;
  const isProfileScope = payload.scope === 'profile';
  const profileId = typeof payload.profileId === 'string' ? payload.profileId : undefined;
  return buildDebugLogsExportPayload(isProfileScope ? { profileId, profile: payload.profile } : undefined)
    .then(result => ({ ok: true, result }))
    .catch(error => ({ ok: false, error: safeStringify(error) }));
});

browser.storage.onChanged.addListener(async (changes, areaName) => {
  logger.debug('Storage changes detected in area:', areaName);

  if (areaName === 'local') {
    const relevantKeys = [
      BrowserStorageKey.Profiles,
      BrowserStorageKey.SelectedProfile,
      BrowserStorageKey.IsPaused,
      BrowserStorageKey.HeadersConfigMeta,
    ];
    const changedKeys = Object.keys(changes);
    const relevantChangedKeys = relevantKeys.filter(key => changedKeys.includes(key));

    if (relevantChangedKeys.length > 0) {
      // Log details about what changed
      const changeDetails: Record<string, { hadOldValue: boolean; hasNewValue: boolean }> = {};
      for (const key of relevantChangedKeys) {
        const change = changes[key];
        changeDetails[key] = {
          hadOldValue: change?.oldValue !== undefined,
          hasNewValue: change?.newValue !== undefined,
        };
      }

      logger.info('📝 Relevant storage changes detected:', {
        changedKeys: relevantChangedKeys,
        changeDetails,
        currentQueueState: {
          lastAppliedStorageFingerprint,
          lastAppliedMeta,
          applyInProgress,
          applyPending,
        },
      });

      await applyHeadersFromStorageQueue('storage.onChanged');
    }
  }
});

browser.runtime.onInstalled.addListener(async details => {
  logger.info('Extension installed/updated:', details.reason);

  const result = await browser.storage.local.get([
    BrowserStorageKey.Profiles,
    BrowserStorageKey.SelectedProfile,
    BrowserStorageKey.IsPaused,
    BrowserStorageKey.HeadersConfigMeta,
  ]);

  // Detailed logging of storage contents on install/update
  logger.group('📦 Storage contents on install/update:', true);
  logger.info('  - Profiles:', result[BrowserStorageKey.Profiles] ? 'Present' : 'Missing');
  logger.info('  - Selected Profile:', result[BrowserStorageKey.SelectedProfile] || 'None');
  logger.info('  - Is Paused:', result[BrowserStorageKey.IsPaused] || false);
  logger.debug('Install/update storage data:', JSON.stringify(result, null, 2));
  logger.groupEnd();

  // Log profile count if present
  if (result[BrowserStorageKey.Profiles]) {
    try {
      const profiles = JSON.parse(result[BrowserStorageKey.Profiles] as string);
      logger.info(`  - Profiles count: ${profiles.length}`);
      if (profiles.length > 0) {
        logger.info('  - Profile names:', profiles.map((p: Profile) => p.name || p.id).join(', '));
      }
    } catch (error) {
      logger.warn('  - Failed to parse profiles:', error);
    }
  }

  logger.debug('Install/update storage data:', result);

  if (Object.keys(result).length) {
    logger.info('🔧 Storage data found, initializing browser headers on install/update');
    await applyHeadersFromStorageQueue(`runtime.onInstalled:${details.reason}`);
  } else {
    logger.info('📭 No storage data found on install/update - extension will start with default settings');
  }
});

// Badge depends on the active tab URL when URL filters are configured.
browser.tabs.onActivated.addListener(async activeInfo => {
  logger.debug('Tab activated:', activeInfo);

  const result = await browser.storage.local.get([
    BrowserStorageKey.Profiles,
    BrowserStorageKey.SelectedProfile,
    BrowserStorageKey.IsPaused,
  ]);

  logger.debug('Tab activation storage data:', result);

  if (Object.keys(result).length) {
    logger.info('📱 Tab activated, updating badge');
    try {
      const tab = await browser.tabs.get(activeInfo.tabId);
      await refreshBadgeFromStorage(result, tab.url);
    } catch (error) {
      logger.error('Failed to refresh badge on tab activation:', error);
    }
  } else {
    logger.debug('No storage data found on tab activation');
  }
});

browser.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;

  const activeTabs = await browser.tabs.query({ active: true, currentWindow: true });
  if (activeTabs[0]?.id !== tabId) return;

  logger.debug('Active tab URL updated:', tab.url);

  const result = await browser.storage.local.get([
    BrowserStorageKey.Profiles,
    BrowserStorageKey.SelectedProfile,
    BrowserStorageKey.IsPaused,
  ]);

  if (Object.keys(result).length) {
    try {
      await refreshBadgeFromStorage(result, tab.url);
    } catch (error) {
      logger.error('Failed to refresh badge on tab URL update:', error);
    }
  }
});

// Sync DNR rules on every service worker startup.
//
// MV3 service workers are killed by Chrome after ~30s of inactivity and restarted on demand.
// onStartup only fires on browser start; onInstalled only fires on extension install/update.
// Neither fires on a plain SW restart, so stale dynamic rules from the previous session
// (which persist across SW restarts) would never be cleaned up until storage changes.
//
// By triggering an apply here, we reconcile DNR state with storage on every SW start.
// The meta/fingerprint deduplication in applyHeadersFromStorageQueue prevents redundant applies.
//
// IMPORTANT: Before starting the full apply (which reads storage first, ~200ms total),
// we eagerly remove all current dynamic rules. This eliminates the window where a disabled
// header from a previous SW session is still active as a stale DNR rule (e.g. after computer
// unlock). The apply that follows will re-add only the currently enabled headers.
const SW_INIT_MAX_RETRIES = 3;
const SW_INIT_RETRY_DELAY_MS = 200;

async function clearDynamicRulesOnSwInit(): Promise<void> {
  try {
    const staleRules = await browser.declarativeNetRequest.getDynamicRules();
    if (staleRules.length === 0) {
      logger.debug('🧹 sw-init: no stale dynamic rules');
      return;
    }
    logger.info('🧹 sw-init: clearing stale dynamic rules:', {
      count: staleRules.length,
      ids: staleRules.map(r => r.id),
    });

    let lastError: unknown = null;
    for (let attempt = 1; attempt <= SW_INIT_MAX_RETRIES; attempt++) {
      try {
        await browser.declarativeNetRequest.updateDynamicRules({
          removeRuleIds: staleRules.map(r => r.id),
        });
        logger.info('🧹 sw-init: stale dynamic rules cleared');
        return;
      } catch (err) {
        lastError = err;
        logger.warn(
          `⚠️ sw-init: failed to clear stale dynamic rules (attempt ${attempt}/${SW_INIT_MAX_RETRIES}):`,
          err,
        );
        if (attempt < SW_INIT_MAX_RETRIES) {
          const delay = SW_INIT_RETRY_DELAY_MS * attempt;
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }
    logger.warn('⚠️ sw-init: failed to clear stale dynamic rules after retries (apply will handle it):', lastError);
  } catch (err) {
    logger.warn('⚠️ sw-init: failed to clear stale dynamic rules (apply will handle it):', err);
  }
}

// Hold the apply lock during sw-init clear so any concurrent storage.onChanged events
// queue up (applyPending=true) instead of racing with the DNR clear call.
// Concurrent updateDynamicRules calls cause Chrome to throw "Internal error while updating
// dynamic rules" and leave the DNR API broken for the rest of the session.
applyInProgress = true;
clearDynamicRulesOnSwInit().finally(() => {
  applyInProgress = false;
  applyHeadersFromStorageQueue('sw-init').catch(err => {
    logger.error('❌ Failed to apply headers on SW init:', err);
  });
});
