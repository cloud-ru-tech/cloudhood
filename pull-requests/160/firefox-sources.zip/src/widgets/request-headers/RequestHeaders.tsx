import { useUnit } from 'effector-react';

import { $selectedProfileRequestHeaders } from '#entities/request-profile/model/selected-request-headers';
import { requestHeadersReordered } from '#features/selected-profile-request-headers/reorder/model';

import { RequestHeaderRow } from './components/RequestHeaderRow';
import * as S from './styled';

export function RequestHeaders() {
  const { requestHeaders, onDrop } = useUnit({
    requestHeaders: $selectedProfileRequestHeaders,
    onDrop: requestHeadersReordered,
  });
  return (
    <S.Wrapper>
      {requestHeaders.map(header => (
        <RequestHeaderRow
          key={header.id}
          {...header}
          onDrop={onDrop}
        />
      ))}
    </S.Wrapper>
  );
}
