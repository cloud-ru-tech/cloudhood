import { useUnit } from 'effector-react/effector-react.mjs';
import { type ClipboardEvent, type KeyboardEvent, useState } from 'react';

import { ButtonFunction } from '@snack-uikit/button';
import { CrossSVG } from '@snack-uikit/icons';
import { Checkbox, CheckboxProps } from '@snack-uikit/toggles';
import { Tooltip } from '@snack-uikit/tooltip';

import { $isPaused } from '#entities/is-paused/model';
import type { RequestHeader } from '#entities/request-profile/types';
import { DragEndPayload, DragHandle, usePragmaticSortableItem } from '#entities/sortable-list';
import { DELIMITER, NEW_ROW } from '#features/selected-profile-request-headers/paste/constant';
import { selectedProfileRequestHeadersPasted } from '#features/selected-profile-request-headers/paste/model';
import { selectedProfileRequestHeadersRemoved } from '#features/selected-profile-request-headers/remove/model';
import { selectedProfileRequestHeadersUpdated } from '#features/selected-profile-request-headers/update/model';
import { validateHeaderName, validateHeaderValue } from '#shared/utils/headers';

import { RequestHeaderMenu } from './RequestHeaderMenu';
import * as S from './styled';

type RequestHeaderRowProps = RequestHeader & {
  onDrop: (payload: DragEndPayload) => void;
};

export function RequestHeaderRow({ onDrop, ...props }: RequestHeaderRowProps) {
  const { disabled, name, value, id } = props;
  const { isPaused, onRequestHeadersPasted, onRequestHeadersUpdated, onRequestHeadersRemoved } = useUnit({
    isPaused: $isPaused,
    onRequestHeadersPasted: selectedProfileRequestHeadersPasted,
    onRequestHeadersUpdated: selectedProfileRequestHeadersUpdated,
    onRequestHeadersRemoved: selectedProfileRequestHeadersRemoved,
  });

  const isNameFormatVerified = validateHeaderName(name);
  const isValueFormatVerified = validateHeaderValue(value);

  const [headerNameFocused, setHeaderNameFocused] = useState(false);
  const { rowRef } = usePragmaticSortableItem({
    disabled: isPaused,
    id,
    onDrop,
  });

  const onHeaderNameFocused = () => setHeaderNameFocused(true);
  const onHeaderNameBlur = () => setHeaderNameFocused(false);

  const handlePaste = (field: 'value' | 'name') => (e: ClipboardEvent<HTMLInputElement>) => {
    const value = e.clipboardData.getData('text/plain');

    if (![DELIMITER, NEW_ROW].some(item => value.includes(item))) {
      return;
    }

    e.preventDefault();
    onRequestHeadersPasted({ id, value, field });
  };

  const handleKeyPress = (event: KeyboardEvent<HTMLInputElement>) => {
    const target = event.target as HTMLInputElement;
    const cursorPosition = target.selectionStart;
    if (event.key === ' ' && cursorPosition === 0) {
      event.preventDefault();
    }
  };

  const handleChange = (field: 'value' | 'name') => (value: string) => {
    onRequestHeadersUpdated([{ ...props, [field]: value }]);
  };

  const handleChecked: CheckboxProps['onChange'] = checked => {
    onRequestHeadersUpdated([{ ...props, disabled: !checked }]);
  };

  return (
    <S.Wrapper ref={rowRef} data-sortable-id={id}>
      <S.LeftHeaderActions>
        <DragHandle disabled={isPaused} />

        <Checkbox
          data-test-id='request-header-checkbox'
          disabled={isPaused}
          checked={!disabled}
          onChange={handleChecked}
        />
      </S.LeftHeaderActions>

      <S.HeaderFieldWrapper grow={216}>
        <Tooltip
          open={headerNameFocused && name.length > 0 && !isNameFormatVerified}
          tip='Header names may only include Latin characters without spaces and these special symbols: (),/:;<=>?@[]{}")'
          placement='top'
        >
          <S.HeaderNameField
            data-test-id='header-name-input'
            size='m'
            inputMode='text'
            value={name}
            placeholder='Header name'
            onChange={handleChange('name')}
            onPaste={handlePaste('name')}
            onKeyDown={handleKeyPress}
            onFocus={onHeaderNameFocused}
            onBlur={onHeaderNameBlur}
            showClearButton={false}
            disabled={isPaused}
            validationState={name.length > 0 && !isNameFormatVerified ? 'error' : 'default'}
          />
        </Tooltip>
      </S.HeaderFieldWrapper>

      <S.HeaderFieldWrapper grow={205}>
        <Tooltip
          tip='Incorrect format for header value'
          placement='top'
          open={value.length > 0 && !isValueFormatVerified}
        >
          <S.HeaderValueField
            size='m'
            inputMode='text'
            value={value}
            placeholder='Header value'
            onChange={handleChange('value')}
            onPaste={handlePaste('value')}
            onKeyDown={handleKeyPress}
            showClearButton={false}
            disabled={isPaused}
            data-test-id='header-value-input'
            validationState={value.length > 0 && !isValueFormatVerified ? 'error' : 'default'}
          />
        </Tooltip>
      </S.HeaderFieldWrapper>

      <ButtonFunction
        disabled={isPaused}
        size='s'
        data-test-id='remove-request-header-button'
        icon={<CrossSVG />}
        onClick={() => onRequestHeadersRemoved([id])}
      />

      <RequestHeaderMenu {...props} />
    </S.Wrapper>
  );
}
