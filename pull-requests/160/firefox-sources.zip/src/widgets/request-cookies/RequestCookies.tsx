import { useUnit } from 'effector-react';

import { $selectedProfileRequestCookies } from '#entities/request-profile/model/selected-request-cookies';
import { requestCookiesReordered } from '#features/selected-profile-request-cookies/reorder/model';

import { RequestCookieRow } from './components/RequestCookieRow/RequestCookieRow';
import * as S from './styled';

export function RequestCookies() {
  const { requestCookies, onDrop } = useUnit({
    requestCookies: $selectedProfileRequestCookies,
    onDrop: requestCookiesReordered,
  });
  return (
    <S.Wrapper>
      {requestCookies.map(cookie => (
        <RequestCookieRow
          key={cookie.id}
          {...cookie}
          onDrop={onDrop}
        />
      ))}
    </S.Wrapper>
  );
}
