import { useUnit } from 'effector-react';

import { $selectedProfileUrlFilters } from '#entities/request-profile/model';
import { urlFiltersReordered } from '#features/selected-profile-url-filters/reorder/model';

import { UrlFiltersRow } from './components/UrlFiltersRow';
import * as S from './styled';

export function UrlFilters() {
  const { urlFilters, onDrop } = useUnit({
    urlFilters: $selectedProfileUrlFilters,
    onDrop: urlFiltersReordered,
  });
  return (
    <S.Wrapper>
      {urlFilters.map(filter => (
        <UrlFiltersRow
          key={filter.id}
          {...filter}
          onDrop={onDrop}
        />
      ))}
    </S.Wrapper>
  );
}
