import { DragStartEvent } from '@dnd-kit/core';
import { arrayMove } from '@dnd-kit/sortable';
import { attach, combine, sample } from 'effector';

import {
  $requestProfiles,
  $selectedProfileRequestHeaders,
  $selectedRequestProfile,
  profileUpdated,
} from '#entities/request-profile/model';
import {
  createSortableListModel,
  dragEnded,
  dragStarted,
  hasDragEndPayload,
  type SortableItemId,
} from '#entities/sortable-list';

export const {
  $flattenItems: $flattenRequestHeaders,
  $raisedItem: $raisedRequestHeader,
  reorderItems,
  itemsUpdated,
} = createSortableListModel({
  $items: $selectedProfileRequestHeaders,
  $selectedItem: $selectedRequestProfile,
  $allItems: $requestProfiles.map(profiles => profiles.map(profile => profile.requestHeaders)),
  itemsUpdated: profileUpdated,
});

export const $draggableRequestHeader = combine(
  [$raisedRequestHeader, $selectedProfileRequestHeaders],
  ([raisedId, headers]) => (raisedId ? headers.find(header => header.id === raisedId) : null),
);

const reorderRequestHeadersFx = attach({
  source: { profiles: $requestProfiles, selectedProfile: $selectedRequestProfile },
  effect: ({ profiles, selectedProfile }, payload: { active: string | number; target: string | number }) => {
    const { active, target } = payload;

    const profile = profiles.find(p => p.id === selectedProfile);

    if (!profile) {
      return null;
    }

    const requestHeaders = profile.requestHeaders;
    const activeIndex = requestHeaders.findIndex(header => header.id === active);
    const targetIndex = requestHeaders.findIndex(header => header.id === target);

    if (activeIndex === -1 || targetIndex === -1) {
      return null;
    }

    return {
      ...profile,
      requestHeaders: arrayMove(requestHeaders, activeIndex, targetIndex),
    };
  },
});

sample({
  clock: dragStarted,
  filter: (event: DragStartEvent) => Boolean(event.active.id),
  fn: (event: DragStartEvent) => event.active.id as string | number,
  target: $raisedRequestHeader,
});

const requestHeaderMoved = sample({
  clock: dragEnded,
  filter: hasDragEndPayload,
  fn: event => ({ active: event.active.id as SortableItemId, target: event.over.id as SortableItemId }),
});

sample({ clock: requestHeaderMoved, target: reorderRequestHeadersFx });
sample({
  clock: reorderRequestHeadersFx.doneData,
  filter: Boolean,
  target: profileUpdated,
});

$raisedRequestHeader.reset(dragEnded);
