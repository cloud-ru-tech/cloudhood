import { DragStartEvent } from '@dnd-kit/core';
import { arrayMove } from '@dnd-kit/sortable';
import { combine, createEvent, sample } from 'effector';

import {
  $requestProfiles,
  $selectedProfileUrlFilters,
  $selectedRequestProfile,
  profileUpdated,
} from '#entities/request-profile/model';
import {
  createSortableListModel,
  dragCancelled,
  dragEnded,
  type DragEndPayload,
  dragStarted,
  hasDragEndPayload,
  type SortableItemId,
} from '#entities/sortable-list';

export const {
  $flattenItems: $flattenUrlFilters,
  $raisedItem: $raisedUrlFilter,
  reorderItems,
  itemsUpdated,
} = createSortableListModel({
  $items: $selectedProfileUrlFilters,
  $selectedItem: $selectedRequestProfile,
  $allItems: $requestProfiles.map(profiles => profiles.map(profile => profile.urlFilters)),
  itemsUpdated: profileUpdated,
});

export const $draggableUrlFilter = combine([$raisedUrlFilter, $selectedProfileUrlFilters], ([raisedId, filters]) =>
  raisedId ? filters.find(filter => filter.id === raisedId) : null,
);

export const urlFiltersReordered = createEvent<DragEndPayload>();

sample({
  clock: dragStarted,
  filter: (event: DragStartEvent) => Boolean(event.active.id),
  fn: (event: DragStartEvent) => event.active.id as string | number,
  target: $raisedUrlFilter,
});

const urlFilterMoved = sample({
  clock: dragEnded,
  filter: hasDragEndPayload,
  fn: event => ({ active: event.active.id as SortableItemId, target: event.over.id as SortableItemId }),
});

sample({
  clock: urlFilterMoved,
  source: { profiles: $requestProfiles, selectedProfile: $selectedRequestProfile },
  filter: ({ profiles, selectedProfile }, { active, target }) => {
    const urlFilters = profiles.find(profile => profile.id === selectedProfile)?.urlFilters ?? [];

    return urlFilters.some(filter => filter.id === active) && urlFilters.some(filter => filter.id === target);
  },
  fn: ({ profiles, selectedProfile }, { active, target }) => {
    const profile = profiles.find(candidate => candidate.id === selectedProfile);

    if (!profile) {
      throw new Error('Selected request profile is missing');
    }
    const activeIndex = profile.urlFilters.findIndex(filter => filter.id === active);
    const targetIndex = profile.urlFilters.findIndex(filter => filter.id === target);

    return { ...profile, urlFilters: arrayMove(profile.urlFilters, activeIndex, targetIndex) };
  },
  target: profileUpdated,
});

sample({
  clock: urlFiltersReordered,
  source: { profiles: $requestProfiles, selectedProfile: $selectedRequestProfile },
  filter: ({ profiles, selectedProfile }, { active, target }) => {
    const urlFilters = profiles.find(profile => profile.id === selectedProfile)?.urlFilters ?? [];

    return urlFilters.some(filter => filter.id === active) && urlFilters.some(filter => filter.id === target);
  },
  fn: ({ profiles, selectedProfile }, { active, target }) => {
    const profile = profiles.find(candidate => candidate.id === selectedProfile);

    if (!profile) {
      throw new Error('Selected request profile is missing');
    }

    return {
      ...profile,
      urlFilters: arrayMove(
        profile.urlFilters,
        profile.urlFilters.findIndex(filter => filter.id === active),
        profile.urlFilters.findIndex(filter => filter.id === target),
      ),
    };
  },
  target: profileUpdated,
});

$raisedUrlFilter.reset(dragEnded, dragCancelled);
