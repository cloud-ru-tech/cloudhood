import { DragStartEvent } from '@dnd-kit/core';
import { arrayMove } from '@dnd-kit/sortable';
import { attach, combine, sample } from 'effector';

import {
  $requestProfiles,
  $selectedProfileUrlFilters,
  $selectedRequestProfile,
  profileUpdated,
} from '#entities/request-profile/model';
import {
  createSortableListModel,
  dragEnded,
  dragStarted,
  hasDragEndPayload,
  type SortableItemId,
} from '#entities/sortable-list';

export const {
  $flattenItems: $flattenUrlFilters,
  $raisedItem: $raisedUrlFilter,
  reorderItems,
  itemsUpdated,
} = createSortableListModel({
  $items: $selectedProfileUrlFilters,
  $selectedItem: $selectedRequestProfile,
  $allItems: $requestProfiles.map(profiles => profiles.map(profile => profile.urlFilters)),
  itemsUpdated: profileUpdated,
});

export const $draggableUrlFilter = combine([$raisedUrlFilter, $selectedProfileUrlFilters], ([raisedId, filters]) =>
  raisedId ? filters.find(filter => filter.id === raisedId) : null,
);

const reorderUrlFiltersFx = attach({
  source: { profiles: $requestProfiles, selectedProfile: $selectedRequestProfile },
  effect: ({ profiles, selectedProfile }, payload: { active: string | number; target: string | number }) => {
    const { active, target } = payload;

    const profile = profiles.find(p => p.id === selectedProfile);

    if (!profile) {
      return null;
    }

    const urlFilters = profile.urlFilters;
    const activeIndex = urlFilters.findIndex(filter => filter.id === active);
    const targetIndex = urlFilters.findIndex(filter => filter.id === target);

    if (activeIndex === -1 || targetIndex === -1) {
      return null;
    }

    return {
      ...profile,
      urlFilters: arrayMove(urlFilters, activeIndex, targetIndex),
    };
  },
});

sample({
  clock: dragStarted,
  filter: (event: DragStartEvent) => Boolean(event.active.id),
  fn: (event: DragStartEvent) => event.active.id as string | number,
  target: $raisedUrlFilter,
});

const urlFilterMoved = sample({
  clock: dragEnded,
  filter: hasDragEndPayload,
  fn: event => ({ active: event.active.id as SortableItemId, target: event.over.id as SortableItemId }),
});

sample({ clock: urlFilterMoved, target: reorderUrlFiltersFx });
sample({
  clock: reorderUrlFiltersFx.doneData,
  filter: Boolean,
  target: profileUpdated,
});

$raisedUrlFilter.reset(dragEnded);
