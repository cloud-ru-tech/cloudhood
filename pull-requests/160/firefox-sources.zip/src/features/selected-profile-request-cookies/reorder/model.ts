import { DragStartEvent } from '@dnd-kit/core';
import { arrayMove } from '@dnd-kit/sortable';
import { combine, createEvent, sample } from 'effector';

import {
  $requestProfiles,
  $selectedProfileRequestCookies,
  $selectedRequestProfile,
  profileUpdated,
} from '#entities/request-profile/model';
import {
  createSortableListModel,
  dragCancelled,
  dragEnded,
  type DragEndPayload,
  dragStarted,
  hasDragEndPayload,
  type SortableItemId,
} from '#entities/sortable-list';

export const {
  $flattenItems: $flattenRequestCookies,
  $raisedItem: $raisedRequestCookie,
  reorderItems,
  itemsUpdated,
} = createSortableListModel({
  $items: $selectedProfileRequestCookies,
  $selectedItem: $selectedRequestProfile,
  $allItems: $requestProfiles.map(profiles => profiles.map(profile => profile.requestCookies ?? [])),
  itemsUpdated: profileUpdated,
});

export const $draggableRequestCookie = combine(
  [$raisedRequestCookie, $selectedProfileRequestCookies],
  ([raisedId, cookies]) => (raisedId ? cookies.find(cookie => cookie.id === raisedId) : null),
);

export const requestCookiesReordered = createEvent<DragEndPayload>();

sample({
  clock: dragStarted,
  filter: (event: DragStartEvent) => Boolean(event.active.id),
  fn: (event: DragStartEvent) => event.active.id as string | number,
  target: $raisedRequestCookie,
});

const requestCookieMoved = sample({
  clock: dragEnded,
  filter: hasDragEndPayload,
  fn: event => ({ active: event.active.id as SortableItemId, target: event.over.id as SortableItemId }),
});

sample({
  clock: requestCookieMoved,
  source: { profiles: $requestProfiles, selectedProfile: $selectedRequestProfile },
  filter: ({ profiles, selectedProfile }, { active, target }) => {
    const requestCookies = profiles.find(profile => profile.id === selectedProfile)?.requestCookies ?? [];

    return requestCookies.some(cookie => cookie.id === active) && requestCookies.some(cookie => cookie.id === target);
  },
  fn: ({ profiles, selectedProfile }, { active, target }) => {
    const profile = profiles.find(candidate => candidate.id === selectedProfile);

    if (!profile) {
      throw new Error('Selected request profile is missing');
    }
    const requestCookies = profile.requestCookies ?? [];
    const activeIndex = requestCookies.findIndex(cookie => cookie.id === active);
    const targetIndex = requestCookies.findIndex(cookie => cookie.id === target);

    return { ...profile, requestCookies: arrayMove(requestCookies, activeIndex, targetIndex) };
  },
  target: profileUpdated,
});

sample({
  clock: requestCookiesReordered,
  source: { profiles: $requestProfiles, selectedProfile: $selectedRequestProfile },
  filter: ({ profiles, selectedProfile }, { active, target }) => {
    const requestCookies = profiles.find(profile => profile.id === selectedProfile)?.requestCookies ?? [];

    return requestCookies.some(cookie => cookie.id === active) && requestCookies.some(cookie => cookie.id === target);
  },
  fn: ({ profiles, selectedProfile }, { active, target }) => {
    const profile = profiles.find(candidate => candidate.id === selectedProfile);

    if (!profile) {
      throw new Error('Selected request profile is missing');
    }
    const requestCookies = profile.requestCookies ?? [];

    return {
      ...profile,
      requestCookies: arrayMove(
        requestCookies,
        requestCookies.findIndex(cookie => cookie.id === active),
        requestCookies.findIndex(cookie => cookie.id === target),
      ),
    };
  },
  target: profileUpdated,
});

$raisedRequestCookie.reset(dragEnded, dragCancelled);
