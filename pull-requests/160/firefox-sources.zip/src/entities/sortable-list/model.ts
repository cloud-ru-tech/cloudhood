import { DragCancelEvent, DragEndEvent, DragStartEvent } from '@dnd-kit/core';
import { combine, createEvent, createStore, EventCallable, Store } from 'effector';

export type SortableItemId = string | number;
export type SortableItemIdOrNull = SortableItemId | null;

export type SortableItem = {
  id: SortableItemId;
  [key: string]: unknown;
};

export type DragEndPayload = {
  active: SortableItemId;
  target: SortableItemId;
};

type DragEndEventWithTarget = DragEndEvent & {
  over: NonNullable<DragEndEvent['over']>;
};

/**
 * Uses the drop target from the terminal dnd-kit event. `onDragOver` is not
 * guaranteed to run immediately before a pointer is released.
 */
export function hasDragEndPayload(event: DragEndEvent): event is DragEndEventWithTarget {
  return event.over !== null && event.active.id !== event.over.id;
}

export type SortableListConfig<T extends SortableItem, U> = {
  $items: Store<T[]>;
  $selectedItem: Store<SortableItemIdOrNull>;
  $allItems: Store<T[][]>;
  itemsUpdated: EventCallable<U>;
};

export const dragStarted = createEvent<DragStartEvent>();
export const dragEnded = createEvent<DragEndEvent>();
export const dragCancelled = createEvent<DragCancelEvent>();

export function createSortableListModel<T extends SortableItem, U>(config: SortableListConfig<T, U>) {
  const { $items, itemsUpdated } = config;

  const $flattenItems = combine($items, items => items.map(({ id }) => id));
  const $raisedItem = createStore<SortableItemIdOrNull>(null);

  const reorderItems = (payload: DragEndPayload) => {
    const { active, target } = payload;

    // Reordering logic is implemented in specific models
    return {
      active,
      target,
    };
  };

  return {
    $flattenItems,
    $raisedItem,
    reorderItems,
    itemsUpdated,
  };
}
