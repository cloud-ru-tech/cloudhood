import { draggable, dropTargetForElements } from '@atlaskit/pragmatic-drag-and-drop/adapter/element-adapter';
import { DragCancelEvent, DragEndEvent, DragStartEvent } from '@dnd-kit/core';
import { useEffect, useRef } from 'react';

import { DragEndPayload, SortableItemId } from '../model';

type UsePragmaticSortableItemProps = {
  disabled: boolean;
  id: SortableItemId;
  onDrop?: (payload: DragEndPayload) => void;
  onDragCancel?: (event: DragCancelEvent) => void;
  onDragEnd?: (event: DragEndEvent) => void;
  onDragStart?: (event: DragStartEvent) => void;
};

const SORTABLE_ID = 'sortableId';

function getSortableId(value: unknown): SortableItemId | null {
  return typeof value === 'string' || typeof value === 'number' ? value : null;
}

function createDragEndEvent(activeId: SortableItemId, overId: SortableItemId | null): DragEndEvent {
  return { active: { id: activeId }, over: overId === null ? null : { id: overId } } as DragEndEvent;
}

export function usePragmaticSortableItem({ disabled, id, onDrop, onDragCancel, onDragEnd, onDragStart }: UsePragmaticSortableItemProps) {
  const rowRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const element = rowRef.current;
    const dragHandle = element?.querySelector('[data-test-id="drag-handle"]');

    if (!element || !dragHandle) {
      return undefined;
    }

    const cleanupDraggable = draggable({
      element,
      dragHandle,
      canDrag: () => !disabled,
      getInitialData: () => ({ [SORTABLE_ID]: id }),
      onDragStart: () => onDragStart?.({ active: { id } } as DragStartEvent),
      onDrop: ({ location, source }) => {
        const activeId = getSortableId(source.data[SORTABLE_ID]);
        const overId = getSortableId(location.current.dropTargets[0]?.data[SORTABLE_ID]);

        if (activeId === null) {
          onDragCancel?.(createDragEndEvent(id, null) as DragCancelEvent);

          return;
        }

        if (overId === null || activeId === overId) {
          return;
        }

        if (onDrop) {
          onDrop({ active: activeId, target: overId });
        } else {
          onDragEnd?.(createDragEndEvent(activeId, overId));
        }
      },
    });
    const cleanupDropTarget = dropTargetForElements({
      element,
      getData: () => ({ [SORTABLE_ID]: id }),
    });

    return () => {
      cleanupDraggable();
      cleanupDropTarget();
    };
  }, [disabled, id, onDrop, onDragCancel, onDragEnd, onDragStart]);

  return { rowRef };
}
