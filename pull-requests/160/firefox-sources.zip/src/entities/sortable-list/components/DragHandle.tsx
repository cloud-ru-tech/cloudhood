import { ButtonFunction } from '@snack-uikit/button';

import { DragIndicatorSVG } from '#shared/assets/svg';

type DragHandleProps = {
  disabled?: boolean;
  icon?: React.ReactElement;
  size?: 's' | 'm' | 'l';
};

export function DragHandle({
  disabled = false,
  icon = <DragIndicatorSVG />,
  size = 's',
}: DragHandleProps) {
  return (
    <span
      data-test-id='drag-handle'
      role='button'
      tabIndex={disabled ? -1 : 0}
      onKeyDown={event => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
        }
      }}
    >
      <ButtonFunction disabled={disabled} size={size} icon={icon} />
    </span>
  );
}
