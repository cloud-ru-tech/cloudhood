import { attach, combine, createEvent, createStore, sample } from 'effector';

import { notificationAdded } from '#entities/notification/model';
import { NotificationInfo, NotificationVariant } from '#entities/notification/types';
import { $requestProfiles, $selectedRequestProfile } from '#entities/request-profile/model';
import { copyToClipboard } from '#shared/utils/copyToClipboard';

import { COPY_RESULT_STATUS } from './constants';
import { downloadSelectedProfiles } from './utils';

export const $profileExportList = combine($requestProfiles, profiles => profiles.map(p => p.id));

export const profileNameExportChanged = createEvent<string[]>();

export const profileExportStringChanged = createEvent<string>();

const $selectedProfileExportList = createStore<string[]>([]).on(profileNameExportChanged, (_, item) =>
  item.map(id => id),
);

export const $selectedExportProfileIdList = combine(
  $selectedProfileExportList,
  $profileExportList,
  $selectedRequestProfile,
  (selectedProfileName, profileIds, currentProfileId) => {
    // Until the user picks something explicitly, default to the currently selected profile.
    const effectiveSelection = selectedProfileName.length > 0 ? selectedProfileName : [currentProfileId];

    return profileIds.filter(profileId => effectiveSelection.includes(profileId)) || [];
  },
  { skipVoid: false },
);

const $customProfileExportString = createStore<string | null>(null);

export const $profileExportString = combine(
  $requestProfiles,
  $selectedExportProfileIdList,
  $customProfileExportString,
  (profiles, selectedExportProfileIdList, customProfileExportString) => {
    if (customProfileExportString !== null) {
      return customProfileExportString;
    }

    return JSON.stringify(
      profiles
        .filter(({ id }) => selectedExportProfileIdList.includes(id))
        // eslint-disable-next-line @typescript-eslint/no-unused-vars -- if the model is extended, this may become an error
        .map(({ id, requestHeaders, requestCookies, urlFilters, ...rest }) => ({
          ...rest,
          // eslint-disable-next-line @typescript-eslint/no-unused-vars -- if the model is extended, this may become an error
          requestHeaders: requestHeaders.map(({ id, ...headerRest }) => headerRest),
          // eslint-disable-next-line @typescript-eslint/no-unused-vars -- if the model is extended, this may become an error
          requestCookies: (requestCookies ?? []).map(({ id, ...cookieRest }) => cookieRest),
          // eslint-disable-next-line @typescript-eslint/no-unused-vars -- if the model is extended, this may become an error
          urlFilters: urlFilters?.map(({ id, ...filterRest }) => filterRest) || [],
        })) || [],
    );
  },
  { skipVoid: false },
);

export const $profilesNameOptions = combine(
  $requestProfiles,
  $selectedExportProfileIdList,
  (requestProfiles, selectedExportProfileIdList) =>
    requestProfiles.map((p, index) => ({
      id: p.id,
      content: { label: `Profile ${index + 1}` },
      disabled: selectedExportProfileIdList.length === 1 && selectedExportProfileIdList[0] === p.id,
    })),
  { skipVoid: false },
);

export const $selectedExportProfileValue = combine(
  $selectedExportProfileIdList,
  $profilesNameOptions,
  (selectedProfileIdList, profilesNameOptions) =>
    profilesNameOptions.filter(({ id }) => selectedProfileIdList.includes(id)).map(({ id }) => id),
  { skipVoid: false },
);

export const profileExportSaved = createEvent();
export const profileExportDownloaded = createEvent();

const profileExportCopyToClipboardFx = attach({
  source: $profileExportString,
  effect: profilesString => {
    const isSupportClipboard = 'clipboard' in navigator;
    if (!isSupportClipboard) {
      throw new Error('Clipboard API is not supported in your browser');
    }
    copyToClipboard(profilesString);
  },
});

const profileExportDownloadFileFx = attach({
  source: $profileExportString,
  effect: serializedProfiles => downloadSelectedProfiles(serializedProfiles),
});

sample({
  source: profileExportStringChanged,
  target: $customProfileExportString,
});

sample({
  clock: profileExportSaved,
  target: profileExportCopyToClipboardFx,
});

sample({
  clock: profileExportDownloaded,
  target: profileExportDownloadFileFx,
});

sample({
  source: profileExportCopyToClipboardFx.doneData,
  fn: (): NotificationInfo => ({
    variant: NotificationVariant.Default,
    message: COPY_RESULT_STATUS.Success,
  }),
  target: notificationAdded,
});

sample({
  source: profileExportCopyToClipboardFx.failData,
  fn: (): NotificationInfo => ({
    variant: NotificationVariant.Default,
    message: COPY_RESULT_STATUS.Error,
  }),
  target: notificationAdded,
});
