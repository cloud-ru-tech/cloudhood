import styled from '@emotion/styled';

import { FieldText } from '@cloud-ru/ds-fields';
import { themeVars } from '@cloud-ru/ds-figma-variables';
import { Droplist } from '@cloud-ru/ds-list';

export const Wrapper = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  gap: 4px;

  width: 100%;
  &.sortable-ghost {
    opacity: 0.28;
  }

  &.sortable-fallback {
    opacity: 0.96;
    border-radius: 12px;
    box-shadow: ${themeVars.sn.boxShadow.elevation.level3};
  }
`;

export const LeftHeaderActions = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 4px;
`;

const legacyFieldStyles = `
  [data-test-id='field-container-private'] {
    border-radius: 12px;
  }
`;

export const CookieFieldWrapper = styled.div<{ grow: number }>`
  flex: ${props => props.grow} 1 0;
  min-width: 0;
`;

export const CookieNameField = styled(FieldText)`
  ${legacyFieldStyles}
`;

export const CookieValueField = styled(FieldText)`
  ${legacyFieldStyles}
`;

export const StyledDroplist = styled(Droplist)`
  width: 228px;
`;
