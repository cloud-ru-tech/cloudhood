import { useUnit } from 'effector-react/effector-react.mjs';
import { type ClipboardEvent, type KeyboardEvent } from 'react';

import { Button } from '@cloud-ru/ds-button';
import { FieldText } from '@cloud-ru/ds-fields';
import { CrossSVG } from '@cloud-ru/ds-icons/interface/system';
import { Checkbox, CheckboxProps } from '@cloud-ru/ds-toggles';
import { Tooltip } from '@cloud-ru/ds-tooltip';

import { $isPaused } from '#entities/is-paused/model';
import type { UrlFilter } from '#entities/request-profile/types';
import { DragHandle } from '#entities/sortable-list';
import { selectedProfileUrlFiltersRemoved } from '#features/selected-profile-url-filters/remove/model';
import { selectedProfileUrlFiltersUpdated } from '#features/selected-profile-url-filters/update/model';
import { validateUrlFilter } from '#shared/utils/createUrlCondition';
import { validateHeaderValue } from '#shared/utils/headers';

import * as S from './styled';
import { UrlFiltersMenu } from './UrlFiltersMenu';

type UrlFiltersRowProps = UrlFilter & {
  onMove: (direction: -1 | 1) => void;
};

export function UrlFiltersRow({ onMove, ...props }: UrlFiltersRowProps) {
  const { disabled, value, id } = props;
  const { isPaused, onUrlFiltersUpdated, onUrlFiltersRemoved } = useUnit({
    isPaused: $isPaused,
    onUrlFiltersUpdated: selectedProfileUrlFiltersUpdated,
    onUrlFiltersRemoved: selectedProfileUrlFiltersRemoved,
  });

  const isValueFormatVerified = validateHeaderValue(value);
  const urlFilterValidation = validateUrlFilter(value);
  const handlePaste = (e: ClipboardEvent<HTMLInputElement>) => {
    const value = e.clipboardData.getData('text/plain');

    e.preventDefault();
    onUrlFiltersUpdated([{ ...props, value }]);
  };

  const handleKeyPress = (event: KeyboardEvent<HTMLInputElement>) => {
    const target = event.target as HTMLInputElement;
    const cursorPosition = target.selectionStart;
    if (event.key === ' ' && cursorPosition === 0) {
      event.preventDefault();
    }
  };

  const handleChange = (value: string) => {
    onUrlFiltersUpdated([{ ...props, value }]);
  };

  const handleChecked: CheckboxProps['onChange'] = checked => {
    onUrlFiltersUpdated([{ ...props, disabled: !checked }]);
  };

  return (
    <S.Wrapper data-sortable-id={id}>
      <DragHandle disabled={isPaused} onMove={onMove} />
      <Checkbox disabled={isPaused} checked={!disabled} onChange={handleChecked} data-test-id='url-filter-checkbox' />

      <S.UrlFilterFieldWrapper>
        <Tooltip
          tip={(() => {
            if (!isValueFormatVerified) {
              return 'Incorrect format for filter value';
            }
            if (urlFilterValidation.warnings.length > 0) {
              return urlFilterValidation.warnings.join('\n');
            }
            return undefined;
          })()}
          placement='top'
          open={value.length > 0 && (!isValueFormatVerified || urlFilterValidation.warnings.length > 0)}
        >
          <FieldText
            size='l'
            inputMode='text'
            value={value}
            placeholder='.*://url.domain/.*'
            onChange={handleChange}
            onPaste={handlePaste}
            onKeyDown={handleKeyPress}
            showClearButton={false}
            disabled={isPaused}
            data-test-id='url-filter-input'
            validationState={
              value.length > 0 && (!isValueFormatVerified || !urlFilterValidation.isValid) ? 'error' : 'default'
            }
          />
        </Tooltip>
      </S.UrlFilterFieldWrapper>

      <Button
        view='function'
        appearance='neutral'
        disabled={isPaused}
        size='m'
        icon={<CrossSVG />}
        onClick={() => onUrlFiltersRemoved([id])}
        data-test-id='remove-url-filter-button'
      />
      <UrlFiltersMenu {...props} />
    </S.Wrapper>
  );
}
