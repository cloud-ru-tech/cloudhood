import { createEvent } from 'effector';

export const initApp = createEvent();
