# CloudHood Firefox Build Instructions

## System Requirements

- Node.js 18 or higher
- pnpm 10.10.0 or higher

## Install Dependencies

```bash
pnpm install
```

## Build the Extension

To build the Firefox extension, run:

```bash
pnpm build:firefox
```

The built extension will be located in `build/firefox/`.

## Additional Commands

- `pnpm lint` - lint the codebase
- `pnpm test:unit` - run unit tests
- `pnpm start:firefox` - start Firefox development mode
- `pnpm build:chromium` - build for Chromium/Chrome

## Project Structure

- `src/` - extension source code
- `scripts/` - build scripts
- `manifest.firefox.json` - Firefox manifest
- `manifest.chromium.json` - Chromium manifest
- `webpack.config.js` - Webpack configuration
- `tsconfig.json` - TypeScript configuration

## Configuration Files

- `lint-staged.config.mjs` - pre-commit hooks configuration
- `stylelint.config.cjs` - StyleLint configuration
- `vitest.config.ts` - test configuration

## Notes

This archive contains the full CloudHood extension source code.
All dependencies are listed in package.json and installed automatically when running `pnpm install`.

The extension supports both Firefox and Chromium browsers.
Separate manifests are used for each browser type.
