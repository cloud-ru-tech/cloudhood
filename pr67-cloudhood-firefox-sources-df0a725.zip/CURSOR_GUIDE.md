# 🎯 Cursor Guide for Cloudhood | Руководство по работе с Cursor для проекта Cloudhood

## Overview | Обзор
This guide will help you work effectively with the Cloudhood project in Cursor IDE, using AI assistant capabilities for understanding architecture, code search, and development.

RU: Это руководство поможет эффективно работать с проектом Cloudhood в Cursor IDE, используя возможности AI-ассистента для понимания архитектуры, поиска кода и разработки.

## 🗂️ Project Structure for Cursor | Структура проекта для Cursor

### Key Directories for Understanding | Ключевые директории для понимания
```
src/
├── entities/          # 🏗️ Business entities (architecture foundation) | Бизнес-сущности (основа архитектуры)
├── features/          # ⚡ User features | Пользовательские функции
├── widgets/           # 🧩 High-level UI components | UI компоненты высокого уровня
├── pages/             # 📄 Application pages | Страницы приложения
├── shared/            # 🔧 Shared utilities and components | Общие утилиты и компоненты
└── background.ts      # 🔄 Extension Service Worker | Service Worker расширения
```

## 🔍 Search and Navigation in Cursor | Поиск и навигация в Cursor

### Common Search Queries | Часто используемые запросы для поиска

#### Search by Functionality | Поиск по функциональности
```
# Search profile logic | Поиск логики профилей
"request profile" OR "профиль" in entities/request-profile/

# Search header management | Поиск управления заголовками
"request headers" OR "заголовки" in features/selected-profile-request-headers/

# Search UI components | Поиск UI компонентов
"header" OR "sidebar" in widgets/

# Search utilities | Поиск утилит
"browser API" OR "storage" in shared/utils/
```

#### Search by Architecture Layers | Поиск по архитектурным слоям
```
# Search business logic | Поиск бизнес-логики
"effector" OR "createEvent" OR "createStore" in entities/ and features/

# Search UI components | Поиск UI компонентов
"React" OR "useState" OR "useEffect" in widgets/ and pages/

# Search integrations | Поиск интеграций
"chrome" OR "browser" in background.ts and shared/utils/
```

### Contextual AI Queries | Контекстные запросы для AI

#### For Understanding Architecture | Для понимания архитектуры
```
"Explain the Cloudhood project architecture" | "Объясни архитектуру проекта Cloudhood"
"How does Feature-Sliced Design work in this project?" | "Как работает Feature-Sliced Design в этом проекте?"
"Show connections between entities, features, and widgets" | "Покажи связи между entities, features и widgets"
```

#### For Finding Specific Functionality | Для поиска конкретной функциональности
```
"Where are HTTP headers processed?" | "Где обрабатываются HTTP заголовки?"
"How does profile export work?" | "Как работает экспорт профилей?"
"Where is Service Worker configured?" | "Где настраивается Service Worker?"
```

#### For Developing New Features | Для разработки новых функций
```
"How to add a new feature to FSD architecture?" | "Как добавить новую функцию в архитектуру FSD?"
"Where to create a new UI component?" | "Где создать новый UI компонент?"
"How to integrate with Chrome Extension API?" | "Как интегрировать с Chrome Extension API?"
```

## 📋 Component Creation Templates | Шаблоны для создания компонентов

### Creating a New Feature | Создание новой Feature
```typescript
// features/new-feature/model.ts
import { createEvent, createStore } from 'effector';

export const newFeatureEvent = createEvent<string>();
export const $newFeatureStore = createStore<string>('');

$newFeatureStore.on(newFeatureEvent, (_, payload) => payload);
```

### Creating a New Widget | Создание нового Widget
```typescript
// widgets/new-widget/NewWidget.tsx
import { useUnit } from 'effector-react';
import { $newFeatureStore } from '#features/new-feature/model';

export function NewWidget() {
  const [value] = useUnit([$newFeatureStore]);

  return <div>{value}</div>;
}
```

### Creating a New Entity | Создание новой Entity
```typescript
// entities/new-entity/model.ts
import { createEvent, createStore } from 'effector';

export interface NewEntity {
  id: string;
  name: string;
}

export const $newEntityStore = createStore<NewEntity[]>([]);
export const addNewEntity = createEvent<NewEntity>();
```

## 🛠️ Useful Cursor Commands | Полезные команды Cursor

### Code Search | Поиск по коду
- `Cmd+Shift+F` - global search | глобальный поиск
- `Cmd+P` - quick file navigation | быстрый переход к файлу
- `Cmd+Shift+O` - search symbols in file | поиск символов в файле

### AI Assistant | AI-ассистент
- `Cmd+K` - open AI chat | открыть AI чат
- `Cmd+L` - explain selected code | объяснить выделенный код
- `Cmd+I` - inline editing with AI | инлайн редактирование с AI

### Refactoring | Рефакторинг
- `F2` - rename symbol | переименование символа
- `Cmd+Shift+R` - refactor in scope | рефакторинг в области видимости
- `Cmd+.` - quick fixes | быстрые исправления

## 🎯 Project-Specific Queries | Специфичные для проекта запросы

### Understanding Effector Architecture | Понимание Effector архитектуры
```
"Show all Effector stores in the project" | "Покажи все Effector stores в проекте"
"How are events and stores connected in request-profile?" | "Как связаны events и stores в request-profile?"
"Where is useUnit hook used?" | "Где используется useUnit hook?"
```

### Working with Chrome Extension API | Работа с Chrome Extension API
```
"How does Declarative Net Request work?" | "Как работает Declarative Net Request?"
"Where are permissions configured in manifest?" | "Где настраиваются permissions в manifest?"
"How does Service Worker work in background.ts?" | "Как работает Service Worker в background.ts?"
```

### UI Components and Styling | UI компоненты и стилизация
```
"What @snack-uikit components are used?" | "Какие компоненты из @snack-uikit используются?"
"How is theming configured in the project?" | "Как настроена темизация в проекте?"
"Where are profile colors defined?" | "Где определены цвета профилей?"
```

## 📚 Contextual AI Tips | Контекстные подсказки для AI

### When Working with New Code | При работе с новым кодом
```
"Does this code follow Feature-Sliced Design architecture?" | "Этот код следует архитектуре Feature-Sliced Design?"
"Which FSD layer is suitable for this functionality?" | "Какой слой FSD подходит для этой функциональности?"
"Is there similar logic in the project?" | "Есть ли аналогичная логика в проекте?"
```

### When Debugging | При отладке
```
"Where could the error be in this call chain?" | "Где может быть ошибка в этой цепочке вызовов?"
"How to check Effector store state?" | "Как проверить состояние Effector store?"
"What logs help debug this issue?" | "Какие логи помогают отладить проблему?"
```

### When Optimizing | При оптимизации
```
"Can this component be optimized?" | "Можно ли оптимизировать этот компонент?"
"Is there code duplication in the project?" | "Есть ли дублирование кода в проекте?"
"How to improve this code's performance?" | "Как улучшить производительность этого кода?"
```

## 🔧 Cursor Settings for Project | Настройка Cursor для проекта

### Recommended Extensions | Рекомендуемые расширения
- **TypeScript Importer** - auto-import TypeScript modules | автоимпорт TypeScript модулей
- **Auto Rename Tag** - sync tag renaming | синхронное переименование тегов
- **Bracket Pair Colorizer** - colored brackets | цветные скобки
- **GitLens** - extended Git integration | расширенная Git интеграция

### Workspace Settings | Настройки workspace
```json
{
  "typescript.preferences.includePackageJsonAutoImports": "on",
  "typescript.suggest.autoImports": true,
  "editor.codeActionsOnSave": {
    "source.organizeImports": true,
    "source.fixAll.eslint": true
  },
  "search.exclude": {
    "**/node_modules": true,
    "**/build": true,
    "**/dist": true
  }
}
```

## 🚀 Quick Actions | Быстрые действия

### Creating a New Profile | Создание нового профиля
1. Find `entities/request-profile/model/` | Найти `entities/request-profile/model/`
2. Study existing stores and events | Изучить существующие stores и events
3. Create similar structure for new profile type | Создать аналогичную структуру для нового типа профиля

### Adding a New Header | Добавление нового заголовка
1. Find `features/selected-profile-request-headers/` | Найти `features/selected-profile-request-headers/`
2. Study CRUD operations | Изучить CRUD операции
3. Add new operation by analogy | Добавить новую операцию по аналогии

### Creating a New Modal | Создание нового модального окна
1. Find `widgets/modals/components/` | Найти `widgets/modals/components/`
2. Study existing modals | Изучить существующие модальные окна
3. Create new component by template | Создать новый компонент по шаблону

## 🐛 Debugging and Diagnostics | Отладка и диагностика

### Error Search | Поиск ошибок
```
"Where could the Chrome Extension API error be?" | "Где может быть ошибка с Chrome Extension API?"
"How to check Service Worker operation?" | "Как проверить работу Service Worker?"
"Where are errors logged in the project?" | "Где логируются ошибки в проекте?"
```

### Performance Analysis | Анализ производительности
```
"Where could performance bottlenecks be?" | "Где могут быть узкие места в производительности?"
"How to optimize list rendering?" | "Как оптимизировать рендеринг списков?"
"Are there memory issues with Effector stores?" | "Есть ли проблемы с памятью в Effector stores?"
```

## 📖 Additional Resources | Дополнительные ресурсы

### Technology Documentation | Документация технологий
- [Effector](https://effector.dev/) - state management | управление состоянием
- [Feature-Sliced Design](https://feature-sliced.design/) - architecture | архитектура
- [Chrome Extensions](https://developer.chrome.com/docs/extensions/) - extension API | API расширений
- [Playwright](https://playwright.dev/) - E2E testing | E2E тестирование

### Internal Resources | Внутренние ресурсы
- `PROJECT_MAP.md` - detailed project map | подробная карта проекта
- `README.md` - general project info | общая информация о проекте
- `RELEASE_SETUP.md` - release configuration | настройка релизов

---

## 💡 Tips for Effective Work | Советы по эффективной работе

1. **Start with architecture | Начинайте с архитектуры** - understand FSD layer before writing code | понимайте слой FSD перед написанием кода
2. **Use context search | Используйте поиск по контексту** - find similar functionality | ищите аналогичную функциональность
3. **Follow patterns | Следуйте паттернам** - use existing Effector patterns | используйте существующие паттерны Effector
4. **Test changes | Тестируйте изменения** - run unit and E2E tests | запускайте unit и E2E тесты
5. **Document complex logic | Документируйте сложную логику** - add comments to non-obvious code | добавляйте комментарии к неочевидному коду
