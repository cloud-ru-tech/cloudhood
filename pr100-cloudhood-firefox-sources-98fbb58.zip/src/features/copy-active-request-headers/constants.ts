export enum COPY_RESULT_STATUS {
  Success = 'Copied request headers to clipboard.',
  Error = 'Failed to copy request headers.',
}
