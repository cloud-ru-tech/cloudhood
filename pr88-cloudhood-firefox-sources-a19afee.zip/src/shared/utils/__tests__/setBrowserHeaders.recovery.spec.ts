/**
 * Unit tests for setBrowserHeaders DNR recovery behavior.
 *
 * Covers the bug where recoveryUpdateDynamicRules() always returned { success: true }
 * even when the final DNR rule count didn't match the expected count. This caused
 * disabled headers to keep being injected into requests because the stale DNR rule
 * was never actually removed from Chrome's internal state.
 *
 * Reproduction scenario (from real bug report):
 * - Profile has a header (cp-front-billing) marked as disabled: true
 * - Chrome DNR still has an active rule for that header (id: 178804364)
 * - apply() tries to remove the rule → Chrome returns "Internal error while updating dynamic rules"
 * - Recovery strategy also fails → rule count still 1, expected 0
 * - Bug: recovery claimed success anyway → "✅ Rules updated successfully" logged
 * - Fix: recovery now returns { success: false } on count mismatch → session fallback is tried
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import { BrowserStorageKey } from '#shared/constants';

vi.mock('webextension-polyfill', () => ({
  default: {
    declarativeNetRequest: {
      getDynamicRules: vi.fn(),
      updateDynamicRules: vi.fn(),
      getSessionRules: vi.fn(),
      updateSessionRules: vi.fn(),
    },
    runtime: {
      id: 'test-extension-id',
      getURL: vi.fn(() => ''),
    },
  },
}));

vi.mock('../setIconBadge', () => ({
  setIconBadge: vi.fn(),
}));

// These imports must come after vi.mock() calls
import browser from 'webextension-polyfill';

import { setBrowserHeaders } from '../setBrowserHeaders';

// Cast to access vi.fn() methods — these ARE vi.fn() instances because of vi.mock above
const mockDnr = browser.declarativeNetRequest as unknown as {
  getDynamicRules: ReturnType<typeof vi.fn>;
  updateDynamicRules: ReturnType<typeof vi.fn>;
  getSessionRules: ReturnType<typeof vi.fn>;
  updateSessionRules: ReturnType<typeof vi.fn>;
};

// Matches the header id from the real bug report
const STALE_RULE_ID = 178804364;

function makeStaleRule() {
  return {
    id: STALE_RULE_ID,
    action: {
      type: 'modifyHeaders',
      requestHeaders: [{ header: 'cp-front-billing', operation: 'set', value: 'RM-3967' }],
    },
    condition: { resourceTypes: ['main_frame'] },
  };
}

/** Storage snapshot with one disabled header — addRules should be [] on apply */
function makeStorageWithDisabledHeader() {
  const profile = {
    id: 'profile-1',
    requestHeaders: [{ id: STALE_RULE_ID, name: 'cp-front-billing', value: 'RM-3945', disabled: true }],
    urlFilters: [],
  };
  return {
    [BrowserStorageKey.IsPaused]: false,
    [BrowserStorageKey.Profiles]: JSON.stringify([profile]),
    [BrowserStorageKey.SelectedProfile]: 'profile-1',
    [BrowserStorageKey.HeadersConfigMeta]: { seq: 10, updatedAt: Date.now() },
  };
}

const CHROME_INTERNAL_ERROR = new Error('Internal error while updating dynamic rules.');

describe('setBrowserHeaders – DNR recovery', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers();
    // Sensible defaults: no session rules, session updates succeed
    mockDnr.getSessionRules.mockResolvedValue([]);
    mockDnr.updateSessionRules.mockResolvedValue(undefined);
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('happy path – disabled header rule is removed', () => {
    it('calls updateDynamicRules to remove the stale rule when Chrome API succeeds', async () => {
      mockDnr.getDynamicRules.mockResolvedValue([makeStaleRule()]);
      mockDnr.updateDynamicRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(makeStorageWithDisabledHeader());
      await vi.runAllTimersAsync();
      await promise;

      expect(mockDnr.updateDynamicRules).toHaveBeenCalledWith(
        expect.objectContaining({ removeRuleIds: [STALE_RULE_ID], addRules: [] }),
      );
    });

    it('does not add any DNR rules when all headers are disabled', async () => {
      mockDnr.getDynamicRules
        .mockResolvedValueOnce([makeStaleRule()]) // initial state: stale rule present
        .mockResolvedValue([]); // after removal: cleared

      mockDnr.updateDynamicRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(makeStorageWithDisabledHeader());
      await vi.runAllTimersAsync();
      await promise;

      // Every updateDynamicRules call must have addRules: [] — no new rules added
      for (const call of mockDnr.updateDynamicRules.mock.calls) {
        const args = call[0] as { addRules: unknown[] };
        expect(args.addRules).toHaveLength(0);
      }
    });
  });

  describe('Chrome "Internal error while updating dynamic rules" recovery', () => {
    it('triggers session rules fallback when all dynamic rule removals fail and recovery count still mismatches', async () => {
      // Chrome refuses to clear the stale rule — updateDynamicRules always throws,
      // getDynamicRules always returns the stale rule (it was never removed)
      mockDnr.getDynamicRules.mockResolvedValue([makeStaleRule()]);
      mockDnr.updateDynamicRules.mockRejectedValue(CHROME_INTERNAL_ERROR);

      const promise = setBrowserHeaders(makeStorageWithDisabledHeader());
      await vi.runAllTimersAsync();
      // Should NOT throw — session fallback handles it gracefully
      await promise;

      // Session rules fallback must have been tried as last resort
      expect(mockDnr.updateSessionRules).toHaveBeenCalled();
    });

    it('tries one-by-one rule removal in recovery when batch removal fails', async () => {
      // Batch removal in recovery fails, but individual removal succeeds
      mockDnr.getDynamicRules
        .mockResolvedValueOnce([makeStaleRule()]) // initial state
        .mockResolvedValueOnce([makeStaleRule()]) // recovery: before clear
        .mockResolvedValueOnce([]) //              recovery: after clear (one-by-one worked)
        .mockResolvedValueOnce([]) //              recovery: final check (0 === 0 → success)
        .mockResolvedValue([]); //                 final state logging

      mockDnr.updateDynamicRules
        .mockRejectedValueOnce(CHROME_INTERNAL_ERROR) // main retry 1
        .mockRejectedValueOnce(CHROME_INTERNAL_ERROR) // main retry 2
        .mockRejectedValueOnce(CHROME_INTERNAL_ERROR) // main retry 3
        .mockRejectedValueOnce(CHROME_INTERNAL_ERROR) // recovery: batch removal
        .mockResolvedValue(undefined); //              recovery: one-by-one removal succeeds

      const promise = setBrowserHeaders(makeStorageWithDisabledHeader());
      await vi.runAllTimersAsync();
      await promise;

      // There must be a single-rule removal call (removeRuleIds has exactly 1 entry)
      const singleRuleCall = mockDnr.updateDynamicRules.mock.calls.find(call => {
        const args = call[0] as { removeRuleIds: number[]; addRules: unknown[] };
        return (
          args.removeRuleIds?.length === 1 && args.removeRuleIds[0] === STALE_RULE_ID && args.addRules?.length === 0
        );
      });
      expect(singleRuleCall).toBeDefined();

      // Recovery succeeded without session fallback
      expect(mockDnr.updateSessionRules).not.toHaveBeenCalled();
    });

    it('throws when both dynamic rules and session rules APIs are broken', async () => {
      mockDnr.getDynamicRules.mockResolvedValue([makeStaleRule()]);
      mockDnr.updateDynamicRules.mockRejectedValue(CHROME_INTERNAL_ERROR);
      mockDnr.updateSessionRules.mockRejectedValue(new Error('Session rules API also broken'));

      const promise = setBrowserHeaders(makeStorageWithDisabledHeader());
      // Suppress the unhandled rejection that fires during timer advancement
      // (the rejection is properly asserted below via .rejects.toThrow())
      promise.catch(() => {});
      await vi.runAllTimersAsync();

      await expect(promise).rejects.toThrow();
    });
  });

  describe('stuck rule detection – only dynamic rules count', () => {
    it('does not report session rule IDs as stuck even if they are not in addRules', async () => {
      // A leftover counteracting session rule (id >= 1_000_000_000) exists from a previous apply.
      // Dynamic rules are clean, so the apply should succeed and clean it up — stuckRuleIds must be [].
      const counteractRule = {
        id: 1_000_000_000,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: 'cp-front-service-modals', operation: 'remove' }],
        },
        condition: { resourceTypes: ['main_frame'] },
      };

      mockDnr.getDynamicRules.mockResolvedValue([]); // no stuck dynamic rules
      mockDnr.updateDynamicRules.mockResolvedValue(undefined);
      mockDnr.getSessionRules
        .mockResolvedValueOnce([counteractRule]) // initial read — will be cleaned up
        .mockResolvedValue([]); // after cleanup
      mockDnr.updateSessionRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(makeStorageWithDisabledHeader());
      await vi.runAllTimersAsync();
      const result = await promise;

      expect(result.stuckRuleIds).toHaveLength(0);
      expect(result.stuckRuleIds).not.toContain(1_000_000_000);
    });

    it('returns stuckRuleIds only for dynamic rules that were not removed', async () => {
      mockDnr.getDynamicRules.mockResolvedValue([makeStaleRule()]);
      mockDnr.updateDynamicRules.mockRejectedValue(CHROME_INTERNAL_ERROR);
      // Session rules: empty before and after (fallback applies [])
      mockDnr.getSessionRules.mockResolvedValue([]);
      mockDnr.updateSessionRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(makeStorageWithDisabledHeader());
      await vi.runAllTimersAsync();
      const result = await promise;

      expect(result.stuckRuleIds).toEqual([STALE_RULE_ID]);
    });
  });

  describe('counteracting session rules for stuck disabled headers', () => {
    it('adds a session remove rule to suppress a stuck disabled dynamic rule', async () => {
      // All dynamic rule operations fail → stuck rule stays.
      // Since the header is disabled (addRules=[]), the stuck rule has no session counterpart →
      // a counteracting session rule with operation:"remove" must be added.
      mockDnr.getDynamicRules.mockResolvedValue([makeStaleRule()]);
      mockDnr.updateDynamicRules.mockRejectedValue(CHROME_INTERNAL_ERROR);
      mockDnr.getSessionRules.mockResolvedValue([]);
      mockDnr.updateSessionRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(makeStorageWithDisabledHeader());
      await vi.runAllTimersAsync();
      await promise;

      const counteractCall = mockDnr.updateSessionRules.mock.calls.find((call: unknown[]) => {
        const arg = call[0] as {
          addRules?: Array<{
            id: number;
            priority?: number;
            action: { requestHeaders?: Array<{ operation: string; header: string }> };
          }>;
        };
        const { addRules } = arg;
        return addRules?.some(
          rule =>
            rule.id >= 1_000_000_000 &&
            rule.priority === 2 &&
            rule.action.requestHeaders?.some(h => h.operation === 'remove' && h.header === 'cp-front-billing'),
        );
      });
      expect(counteractCall).toBeDefined();
    });

    it('does not remove an existing counteracting session rule when session fallback is invoked', async () => {
      // Regression: sessionRulesFallback used to receive ALL removeSessionRuleIds, including
      // counteracting rules (id >= 1_000_000_000). It would delete them while the stuck
      // dynamic rule remained, opening a window where the disabled header was transmitted.
      // Fix: counteracting rules are excluded from fallbackRemoveSessionRuleIds.
      // The fallback is the one that receives addRules: [] — it must not remove the counteracting rule.
      const COUNTERACT_RULE_ID = 1_000_000_000;
      const existingCounteractRule = {
        id: COUNTERACT_RULE_ID,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: 'cp-front-billing', operation: 'remove' }],
        },
        condition: { resourceTypes: ['main_frame'] },
      };

      mockDnr.getDynamicRules.mockResolvedValue([makeStaleRule()]);
      mockDnr.updateDynamicRules.mockRejectedValue(CHROME_INTERNAL_ERROR);
      // Counteracting rule already exists from a previous apply
      mockDnr.getSessionRules.mockResolvedValue([existingCounteractRule]);
      mockDnr.updateSessionRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(makeStorageWithDisabledHeader());
      await vi.runAllTimersAsync();
      await promise;

      // The fallback calls updateSessionRules with addRules: [] — that call must NOT remove the counteracting rule
      const fallbackCall = mockDnr.updateSessionRules.mock.calls.find((call: unknown[]) => {
        const arg = call[0] as { removeRuleIds?: number[]; addRules?: unknown[] };
        return (arg.addRules?.length ?? 0) === 0;
      });
      expect(fallbackCall).toBeDefined();
      const fallbackArg = (fallbackCall as [unknown])[0] as { removeRuleIds?: number[] };
      expect(fallbackArg.removeRuleIds).not.toContain(COUNTERACT_RULE_ID);
    });

    it('removes stale counteracting rule when the previously-disabled header becomes enabled', async () => {
      // Scenario: header was disabled (counteracting rule added), user re-enables it.
      // Dynamic rules succeed this time, so stuckRuleIds=[]. We must remove the old
      // counteracting rule since the header is now enabled and no longer needs counteracting.
      const COUNTERACT_RULE_ID = 1_000_000_000;
      const existingCounteractRule = {
        id: COUNTERACT_RULE_ID,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: 'cp-front-billing', operation: 'remove' }],
        },
        condition: { resourceTypes: ['main_frame'] },
      };

      const profile = {
        id: 'profile-1',
        requestHeaders: [{ id: STALE_RULE_ID, name: 'cp-front-billing', value: 'RM-3945', disabled: false }],
        urlFilters: [],
      };
      const storage = {
        [BrowserStorageKey.IsPaused]: false,
        [BrowserStorageKey.Profiles]: JSON.stringify([profile]),
        [BrowserStorageKey.SelectedProfile]: 'profile-1',
        [BrowserStorageKey.HeadersConfigMeta]: { seq: 11, updatedAt: Date.now() },
      };

      mockDnr.getDynamicRules.mockResolvedValue([]);
      mockDnr.updateDynamicRules.mockResolvedValue(undefined);
      mockDnr.getSessionRules.mockResolvedValueOnce([existingCounteractRule]).mockResolvedValue([]);
      mockDnr.updateSessionRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(storage);
      await vi.runAllTimersAsync();
      await promise;

      const cleanupCall = mockDnr.updateSessionRules.mock.calls.find((call: unknown[]) => {
        const arg = call[0] as { removeRuleIds?: number[]; addRules?: unknown[] };
        return arg.removeRuleIds?.includes(COUNTERACT_RULE_ID) && (arg.addRules?.length ?? 0) === 0;
      });
      expect(cleanupCall).toBeDefined();
    });

    it('does not add a counteracting rule when the stuck header is already covered by the session fallback', async () => {
      // Scenario: the user deleted a header (id=100, name="x-service") and added a new one
      // with the same name but a fresh id=200. The old dynamic rule (id=100) is stuck.
      // The session fallback applies the new enabled rule (id=200). Because "x-service" is
      // already present in session rules, no additional counteract rule should be added.
      const OLD_RULE_ID = 100;
      const NEW_RULE_ID = 200;
      const HEADER_NAME = 'x-service';

      const stuckDynamicRule = {
        id: OLD_RULE_ID,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: HEADER_NAME, operation: 'set', value: 'old-value' }],
        },
        condition: { resourceTypes: ['main_frame'] },
      };

      const profile = {
        id: 'profile-1',
        requestHeaders: [{ id: NEW_RULE_ID, name: HEADER_NAME, value: 'new-value', disabled: false }],
        urlFilters: [],
      };
      const storage = {
        [BrowserStorageKey.IsPaused]: false,
        [BrowserStorageKey.Profiles]: JSON.stringify([profile]),
        [BrowserStorageKey.SelectedProfile]: 'profile-1',
        [BrowserStorageKey.HeadersConfigMeta]: { seq: 10, updatedAt: Date.now() },
      };

      const sessionFallbackRule = {
        id: NEW_RULE_ID,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: HEADER_NAME, operation: 'set', value: 'new-value' }],
        },
        condition: { resourceTypes: ['main_frame'] },
      };

      mockDnr.getDynamicRules.mockResolvedValue([stuckDynamicRule]);
      mockDnr.updateDynamicRules.mockRejectedValue(CHROME_INTERNAL_ERROR);
      mockDnr.getSessionRules
        .mockResolvedValueOnce([]) // initial read
        .mockResolvedValue([sessionFallbackRule]); // after session fallback applied new-value rule
      mockDnr.updateSessionRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(storage);
      await vi.runAllTimersAsync();
      await promise;

      // No counteracting rule (id >= 1_000_000_000) should have been added
      const counteractCall = mockDnr.updateSessionRules.mock.calls.find((call: unknown[]) =>
        (call[0] as { addRules?: Array<{ id: number }> })?.addRules?.some(rule => rule.id >= 1_000_000_000),
      );
      expect(counteractCall).toBeUndefined();
    });

    it('session fallback rules get priority 3 so they beat stale counteracting rules (priority 2)', async () => {
      // Scenario from bug report (2026-03-31):
      // - cp-agent header is ENABLED
      // - Dynamic rules API is broken after Chrome update
      // - A leftover counteracting rule (id=1_000_000_000, priority=2, REMOVE cp-agent) exists
      //   from a previous fallback cycle
      // - Session fallback adds SET cp-agent at priority 1 (default) → counteracting REMOVE wins → header dropped
      // Fix: session fallback rules must be added at priority 3 (> counteracting priority 2)
      const ACTIVE_RULE_ID = 728548960;
      const COUNTERACT_RULE_ID = 1_000_000_000;

      const stuckDynamicRule = {
        id: ACTIVE_RULE_ID,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: 'cp-agent', operation: 'set', value: 'RM-4012' }],
        },
        condition: { resourceTypes: ['main_frame'] },
      };
      const staleCounteractRule = {
        id: COUNTERACT_RULE_ID,
        priority: 2,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: 'cp-agent', operation: 'remove' }],
        },
        condition: { resourceTypes: ['main_frame'] },
      };

      const profile = {
        id: 'profile-1',
        requestHeaders: [{ id: ACTIVE_RULE_ID, name: 'cp-agent', value: 'RM-4012', disabled: false }],
        urlFilters: [],
      };
      const storage = {
        [BrowserStorageKey.IsPaused]: false,
        [BrowserStorageKey.Profiles]: JSON.stringify([profile]),
        [BrowserStorageKey.SelectedProfile]: 'profile-1',
        [BrowserStorageKey.HeadersConfigMeta]: { seq: 25, updatedAt: Date.now() },
      };

      const sessionFallbackRule = {
        id: ACTIVE_RULE_ID,
        priority: 3,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: 'cp-agent', operation: 'set', value: 'RM-4012' }],
        },
        condition: { resourceTypes: ['main_frame'] },
      };

      mockDnr.getDynamicRules.mockResolvedValue([stuckDynamicRule]);
      mockDnr.updateDynamicRules.mockRejectedValue(CHROME_INTERNAL_ERROR);
      mockDnr.getSessionRules
        .mockResolvedValueOnce([staleCounteractRule]) // initial read — counteracting rule from prev session
        .mockResolvedValue([sessionFallbackRule]); // after session fallback applied
      mockDnr.updateSessionRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(storage);
      await vi.runAllTimersAsync();
      await promise;

      // The session fallback call (adds the active header rule) must use priority 3
      const fallbackCall = mockDnr.updateSessionRules.mock.calls.find((call: unknown[]) => {
        const arg = call[0] as { addRules?: Array<{ id: number; priority?: number }> };
        return arg.addRules?.some(rule => rule.id === ACTIVE_RULE_ID);
      });
      expect(fallbackCall).toBeDefined();
      const fallbackArg = (fallbackCall as [unknown])[0] as {
        addRules: Array<{ id: number; priority?: number }>;
      };
      const addedRule = fallbackArg.addRules.find(r => r.id === ACTIVE_RULE_ID);
      expect(addedRule?.priority).toBe(3);
    });

    it('removes stale counteracting rules when stuckRuleIds is empty (recovered from previous broken session)', async () => {
      // Scenario: previous apply left a counteracting rule, but dynamic rules have since been
      // cleared (e.g. browser restart). Now stuckRuleIds=[], we must remove the stale counteracting rule.
      const COUNTERACT_RULE_ID = 1_000_000_000;
      const existingCounteractRule = {
        id: COUNTERACT_RULE_ID,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: 'cp-front-billing', operation: 'remove' }],
        },
        condition: { resourceTypes: ['main_frame'] },
      };

      mockDnr.getDynamicRules.mockResolvedValue([]);
      mockDnr.updateDynamicRules.mockResolvedValue(undefined);
      mockDnr.getSessionRules.mockResolvedValueOnce([existingCounteractRule]).mockResolvedValue([]);
      mockDnr.updateSessionRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(makeStorageWithDisabledHeader());
      await vi.runAllTimersAsync();
      await promise;

      const cleanupCall = mockDnr.updateSessionRules.mock.calls.find((call: unknown[]) => {
        const arg = call[0] as { removeRuleIds?: number[] };
        return arg.removeRuleIds?.includes(COUNTERACT_RULE_ID);
      });
      expect(cleanupCall).toBeDefined();
    });
  });

  describe('regression: Case 1 – enabled headers not transmitted / Case 2 – disabled headers transmitted', () => {
    // Case 1: header is ENABLED but Chrome DNR API is broken → session fallback must transmit the header.
    // Root cause: stale counteracting rule (priority 2, REMOVE) from a previous broken session beat
    // the new session fallback rule (priority 1 default, SET) → header was dropped silently.
    // Fix: session fallback rules are added at SESSION_FALLBACK_PRIORITY (3) > COUNTERACT_PRIORITY (2).
    it('Case 1: enabled header is transmitted via session fallback even when a stale counteracting rule exists', async () => {
      const ACTIVE_RULE_ID = 728548960;
      const COUNTERACT_RULE_ID = 1_000_000_000;

      const stuckDynamicRule = {
        id: ACTIVE_RULE_ID,
        action: { type: 'modifyHeaders', requestHeaders: [{ header: 'cp-agent', operation: 'set', value: 'RM-4012' }] },
        condition: { resourceTypes: ['main_frame'] },
      };
      const staleCounteractRule = {
        id: COUNTERACT_RULE_ID,
        priority: 2,
        action: { type: 'modifyHeaders', requestHeaders: [{ header: 'cp-agent', operation: 'remove' }] },
        condition: { resourceTypes: ['main_frame'] },
      };

      const profile = {
        id: 'profile-1',
        requestHeaders: [{ id: ACTIVE_RULE_ID, name: 'cp-agent', value: 'RM-4012', disabled: false }],
        urlFilters: [],
      };
      const storage = {
        [BrowserStorageKey.IsPaused]: false,
        [BrowserStorageKey.Profiles]: JSON.stringify([profile]),
        [BrowserStorageKey.SelectedProfile]: 'profile-1',
        [BrowserStorageKey.HeadersConfigMeta]: { seq: 25, updatedAt: Date.now() },
      };

      mockDnr.getDynamicRules.mockResolvedValue([stuckDynamicRule]);
      mockDnr.updateDynamicRules.mockRejectedValue(CHROME_INTERNAL_ERROR);
      mockDnr.getSessionRules
        .mockResolvedValueOnce([staleCounteractRule])
        .mockResolvedValue([{ ...stuckDynamicRule, priority: 3 }]);
      mockDnr.updateSessionRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(storage);
      await vi.runAllTimersAsync();
      await promise;

      // Session fallback must add the active header rule at priority 3 so it beats the stale REMOVE (priority 2)
      const fallbackCall = mockDnr.updateSessionRules.mock.calls.find((call: unknown[]) => {
        const arg = call[0] as { addRules?: Array<{ id: number; priority?: number }> };
        return arg.addRules?.some(r => r.id === ACTIVE_RULE_ID && r.priority === 3);
      });
      expect(fallbackCall).toBeDefined();
    });

    // Case 2: header is DISABLED but Chrome DNR API is broken → stuck dynamic rule keeps transmitting it.
    // Fix: counteracting session rule (priority 2, REMOVE) is added to override the stuck dynamic rule
    // (priority 1 default) so Chrome's static > dynamic > session ordering is bypassed via priority.
    it('Case 2: disabled header is blocked via counteracting session rule (priority 2) that beats stuck dynamic rule', async () => {
      // Stuck dynamic rule transmits the disabled header at default priority 1.
      // A counteracting session rule at priority 2 must remove it.
      mockDnr.getDynamicRules.mockResolvedValue([makeStaleRule()]);
      mockDnr.updateDynamicRules.mockRejectedValue(CHROME_INTERNAL_ERROR);
      mockDnr.getSessionRules.mockResolvedValue([]);
      mockDnr.updateSessionRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(makeStorageWithDisabledHeader());
      await vi.runAllTimersAsync();
      await promise;

      // Counteracting rule must be added at priority 2 (COUNTERACT_PRIORITY) with operation "remove"
      const counteractCall = mockDnr.updateSessionRules.mock.calls.find((call: unknown[]) => {
        const arg = call[0] as {
          addRules?: Array<{
            id: number;
            priority?: number;
            action: { requestHeaders?: Array<{ operation: string }> };
          }>;
        };
        return arg.addRules?.some(
          r =>
            r.id >= 1_000_000_000 && r.priority === 2 && r.action.requestHeaders?.some(h => h.operation === 'remove'),
        );
      });
      expect(counteractCall).toBeDefined();
    });

    it('Case 1 + Case 2 combined: one header enabled, one disabled, both handled correctly when DNR is broken', async () => {
      const ENABLED_RULE_ID = 100;
      const DISABLED_RULE_ID = 200;

      // Both dynamic rules are stuck
      const stuckEnabledRule = {
        id: ENABLED_RULE_ID,
        action: { type: 'modifyHeaders', requestHeaders: [{ header: 'x-enabled', operation: 'set', value: 'yes' }] },
        condition: { resourceTypes: ['main_frame'] },
      };
      const stuckDisabledRule = {
        id: DISABLED_RULE_ID,
        action: { type: 'modifyHeaders', requestHeaders: [{ header: 'x-disabled', operation: 'set', value: 'yes' }] },
        condition: { resourceTypes: ['main_frame'] },
      };

      const profile = {
        id: 'profile-1',
        requestHeaders: [
          { id: ENABLED_RULE_ID, name: 'x-enabled', value: 'yes', disabled: false },
          { id: DISABLED_RULE_ID, name: 'x-disabled', value: 'yes', disabled: true },
        ],
        urlFilters: [],
      };
      const storage = {
        [BrowserStorageKey.IsPaused]: false,
        [BrowserStorageKey.Profiles]: JSON.stringify([profile]),
        [BrowserStorageKey.SelectedProfile]: 'profile-1',
        [BrowserStorageKey.HeadersConfigMeta]: { seq: 10, updatedAt: Date.now() },
      };

      const sessionFallbackRule = {
        id: ENABLED_RULE_ID,
        priority: 3,
        action: { type: 'modifyHeaders', requestHeaders: [{ header: 'x-enabled', operation: 'set', value: 'yes' }] },
        condition: { resourceTypes: ['main_frame'] },
      };

      mockDnr.getDynamicRules.mockResolvedValue([stuckEnabledRule, stuckDisabledRule]);
      mockDnr.updateDynamicRules.mockRejectedValue(CHROME_INTERNAL_ERROR);
      mockDnr.getSessionRules
        .mockResolvedValueOnce([]) // initial read
        .mockResolvedValue([sessionFallbackRule]); // after session fallback
      mockDnr.updateSessionRules.mockResolvedValue(undefined);

      const promise = setBrowserHeaders(storage);
      await vi.runAllTimersAsync();
      await promise;

      // Case 1: session fallback added enabled rule at priority 3
      const fallbackCall = mockDnr.updateSessionRules.mock.calls.find((call: unknown[]) => {
        const arg = call[0] as { addRules?: Array<{ id: number; priority?: number }> };
        return arg.addRules?.some(r => r.id === ENABLED_RULE_ID && r.priority === 3);
      });
      expect(fallbackCall).toBeDefined();

      // Case 2: counteracting rule added for disabled header at priority 2
      const counteractCall = mockDnr.updateSessionRules.mock.calls.find((call: unknown[]) => {
        const arg = call[0] as {
          addRules?: Array<{
            id: number;
            priority?: number;
            action: { requestHeaders?: Array<{ header: string; operation: string }> };
          }>;
        };
        return arg.addRules?.some(
          r =>
            r.id >= 1_000_000_000 &&
            r.priority === 2 &&
            r.action.requestHeaders?.some(h => h.header === 'x-disabled' && h.operation === 'remove'),
        );
      });
      expect(counteractCall).toBeDefined();
    });
  });
});
