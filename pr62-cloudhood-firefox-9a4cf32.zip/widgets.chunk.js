import{s as e,F as n,c as t,P as o,a,b as r,E as s,p as i,d as l,e as c,$ as d,f as u,g as p,h as m,i as f,j as h,k as g,l as b,m as y,n as x,o as v,q as C,r as k,t as w,S,D as V,u as D,v as z,w as E,N as _,x as P,y as M,z as j,A as R,B as A,C as O,G as $}from"./features.chunk.js";import{d as I,o as B,j as H,k as L,q as T,r as q,t as F,c as N,s as U,u as J,v as K,w as G,x as Z,E as W,e as Q,i as X,y as Y,z as ee,A as ne,$ as te,T as oe,a as ae}from"./entities.chunk.js";import{G as re,r as se,j as ie,H as le,I as ce}from"./vendor-react.chunk.js";import{s as de,P as ue,D as pe,U as me,T as fe,C as he,a as ge,d as be,F as ye,e as xe,f as ve,K as Ce,h as ke,i as we,M as Se,H as Ve,j as De,k as ze,l as Ee,m as _e,n as Pe,o as Me,N as je,L as Re,p as Ae,q as Oe,r as $e}from"./snack-ui.chunk.js";import{n as Ie}from"./emotion.chunk.js";import{C as Be,u as He,b as Le,c as Te,S as qe,D as Fe,d as Ne,K as Ue,P as Je}from"./dnd.chunk.js";const Ke=[{background:de.themeVars.sys.primary.accentDefault,border:de.themeVars.sys.primary.textMain,font:de.themeVars.sys.primary.onAccent},{background:de.themeVars.sys.violet.accentDefault,border:de.themeVars.sys.violet.textMain,font:de.themeVars.sys.violet.onAccent},{background:de.themeVars.sys.pink.accentDefault,border:de.themeVars.sys.pink.textMain,font:de.themeVars.sys.pink.onAccent},{background:de.themeVars.sys.red.accentDefault,border:de.themeVars.sys.red.textMain,font:de.themeVars.sys.red.onAccent},{background:de.themeVars.sys.orange.accentDefault,border:de.themeVars.sys.orange.textMain,font:de.themeVars.sys.orange.onAccent},{background:de.themeVars.sys.orange.textDisabled,border:de.themeVars.sys.orange.textSupport,font:de.themeVars.sys.orange.textMain},{background:de.themeVars.sys.yellow.accentDefault,border:de.themeVars.sys.yellow.textMain,font:de.themeVars.sys.yellow.onAccent},{background:de.themeVars.sys.green.textDisabled,border:de.themeVars.sys.green.textSupport,font:de.themeVars.sys.green.textMain},{background:de.themeVars.sys.green.accentDefault,border:de.themeVars.sys.green.textMain,font:de.themeVars.sys.green.onAccent},{background:de.themeVars.sys.blue.accentDefault,border:de.themeVars.sys.blue.textMain,font:de.themeVars.sys.blue.onAccent}],Ge=I.map(e=>e.length>1);function Ze(){const[e]=re([t]);return ie(ge,{appearance:"neutral",size:"m",icon:ie(he,{}),onClick:e})}function We(){const[e,n]=re([q,F]);return ie(ge,{appearance:"neutral",icon:ie(e?a:o,{}),onClick:n,size:"m"})}const Qe=Ie(be)`
  ${de.themeVars.sans.title.l}
`,Xe=Ie.div`
  display: flex;
  gap: 8px;
  align-items: center;
  flex-grow: 1;
`,Ye=Ie.div`
  display: flex;
  flex-grow: 1;
  min-width: 0;
`,en=Ie.div`
  display: flex;
  flex-shrink: 0;
`;function nn(){const[e,n]=se.useState(!1),[t,o,a]=re([N,U,r]),i=se.useRef(null),l=se.useRef(null),c=void 0!==t?.name?t.name:`Profile ${o+1}`,[d,u]=se.useState(c),p=()=>{n(e=>!e),e&&a(d)};return se.useEffect(()=>{e&&i.current?.focus()},[e]),le(Xe,{children:[ie(Ye,{children:e?ie(ye,{size:"m",ref:i,placeholder:"Profile name",value:d,onChange:u,onKeyDown:e=>{"Enter"===e.key&&p()},onBlur:({relatedTarget:e})=>{e!==l.current&&p()},showClearButton:!1}):ie(Qe,{text:c})}),ie(en,{children:ie(ge,{appearance:"neutral",size:"m",ref:l,onClick:p,icon:ie(e?xe:s,{})})})]})}const tn=Ie.div`
  display: flex;
  justify-content: space-between;
  color: ${de.themeVars.sys.neutral.textMain};
  width: 100%;
  padding: 12px;
  align-items: center;
`,on=Ie.div`
  display: flex;
  flex-direction: row;
  align-items: center;
`,an=Ie(ve)`
  width: 328px;
`;function rn(){const[t]=re([U]),[o,a]=se.useState(!1),r=function({onClose:t}){const[o]=re([Ge]),a=se.useCallback(()=>{B(),t()},[t]),r=se.useCallback(()=>{H(),t()},[t]),s=se.useCallback(()=>{L(),t()},[t]),i=se.useCallback(()=>{e(),t()},[t]),l=se.useCallback(()=>{T(),t()},[t]);return se.useMemo(()=>[{id:"add",content:{option:"Add profile"},beforeContent:ie(ue,{}),onClick:a},{id:"import",content:{option:"Import profile"},beforeContent:ie(pe,{}),onClick:r},{id:"import-from-extension",content:{option:"Import from other extension"},beforeContent:ie(n,{}),onClick:s},{id:"export",content:{option:"Export/share profile"},beforeContent:ie(me,{}),onClick:l},{id:"remove",content:{option:"Delete profile"},beforeContent:ie(fe,{}),onClick:i,disabled:!o}],[a,l,s,r,i,o])}({onClose:se.useCallback(()=>{a(!1)},[])});return ie(ce,{children:le(tn,{children:[ie(nn,{},t),le(on,{children:[ie(Ze,{}),ie(We,{}),ie(an,{open:o,onOpenChange:a,placement:"bottom-end",size:"m",items:r,children:ie(ge,{appearance:"neutral",size:"m",icon:ie(Ce,{})})})]})]})})}const sn={},ln=function(e,n,t){let o=Promise.resolve();if(n&&n.length>0){let e=function(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:"fulfilled",value:e}),e=>({status:"rejected",reason:e}))))};document.getElementsByTagName("link");const t=document.querySelector("meta[property=csp-nonce]"),a=t?.nonce||t?.getAttribute("nonce");o=e(n.map(e=>{if((e=function(e){return"/"+e}(e))in sn)return;sn[e]=!0;const n=e.endsWith(".css"),t=n?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${e}"]${t}`))return;const o=document.createElement("link");return o.rel=n?"stylesheet":"modulepreload",n||(o.as="script"),o.crossOrigin="",o.href=e,a&&o.setAttribute("nonce",a),document.head.appendChild(o),n?new Promise((n,t)=>{o.addEventListener("load",n),o.addEventListener("error",()=>t(new Error(`Unable to preload CSS for ${e}`)))}):void 0}))}function a(e){const n=new Event("vite:preloadError",{cancelable:!0});if(n.payload=e,window.dispatchEvent(n),!n.defaultPrevented)throw e}return o.then(n=>{for(const e of n||[])"rejected"===e.status&&a(e.reason);return e().catch(a)})},cn=se.lazy(()=>ln(()=>Promise.resolve().then(()=>fn),void 0).then(e=>({default:e.ExportModal}))),dn=se.lazy(()=>ln(()=>Promise.resolve().then(()=>bn),void 0).then(e=>({default:e.ImportFromExtensionModal}))),un=se.lazy(()=>ln(()=>Promise.resolve().then(()=>vn),void 0).then(e=>({default:e.ImportModal})));function pn(){const[e,n,t]=re([J,K,G]);return le(ce,{children:[e&&ie(se.Suspense,{fallback:null,children:ie(un,{})}),n&&ie(se.Suspense,{fallback:null,children:ie(dn,{})}),t&&ie(se.Suspense,{fallback:null,children:ie(cn,{})})]})}const mn=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`;const fn=Object.freeze(Object.defineProperty({__proto__:null,ExportModal:function(){const[e,n,t,o,a,r]=re([l,c,d,u,p,Z]),s=se.useCallback(e=>{e.length<1||i(e)},[]);return ie(Se,{open:!0,onClose:r,title:"Export profile",approveButton:{onClick:n,label:"Copy"},cancelButton:{onClick:e,label:"Download JSON"},content:le(mn,{children:[ie(ke,{label:"Profiles",selection:"multiple",value:a,size:"m",options:o,onChange:s,showClearButton:!1}),ie(we,{label:"JSON",value:t,onChange:m,minRows:4,maxRows:4,size:"m"})]})})}},Symbol.toStringTag,{value:"Module"})),hn=Ie(Ve)`
  width: 100%;
  position: initial;
`,gn=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`;const bn=Object.freeze(Object.defineProperty({__proto__:null,ImportFromExtensionModal:function(){const[e,n,t,o,{errorMessage:a,errorPosition:r,isError:s}]=re([Q,h,g,b,y]),i=se.useRef(null);se.useEffect(()=>{s&&i.current&&(i.current.focus(),r&&i.current.setSelectionRange(r,r))},[r,s]);const l=se.useMemo(()=>Object.entries(W).map(([e,n])=>({option:e,value:n})),[]),c=se.useRef(null),d=se.useCallback(e=>{const n=e?.[0],t=c.current;t&&(t.value=""),n&&f(n)},[]);return ie(De,{open:!0,onClose:e,children:le(hn,{onFilesUpload:d,description:"Drop files to upload",children:[ie(De.Header,{title:"Import from other extension"}),ie(De.Body,{content:le(gn,{children:[ie(ke,{size:"m",selection:"single",label:"Other extension",value:t??void 0,onChange:x,options:l,showClearButton:!1}),ie(we,{size:"m",ref:i,label:"JSON",value:o,onChange:v,maxRows:4,minRows:4,error:s&&a?a:void 0})]})}),ie(De.Footer,{actions:le(ce,{children:[ie(ze,{size:"m",appearance:"primary",label:"Import",onClick:n}),ie(Ee,{onFilesUpload:d,children:ie(_e,{size:"m",appearance:"neutral",label:"Load file",icon:ie(me,{})})})]})})]})})}},Symbol.toStringTag,{value:"Module"})),yn=[{requestHeaders:[{name:"string",value:"string",disabled:"boolean"}]}],xn=Ie(Ve)`
  width: 100%;
  position: initial;
`;const vn=Object.freeze(Object.defineProperty({__proto__:null,ImportModal:function(){const[e,{errorMessage:n,errorPosition:t,isError:o},a,r]=re([b,y,X,h]),s=se.useRef(null),i=se.useRef(null),l=se.useCallback(e=>{const n=e?.[0],t=s.current;t&&(t.value=""),n&&f(n)},[]);return se.useEffect(()=>{o&&i.current&&(i.current.focus(),t&&i.current.setSelectionRange(t,t))},[t,o]),ie(De,{open:!0,onClose:a,children:le(xn,{onFilesUpload:l,description:"Drop files to upload",children:[ie(De.Header,{title:"Import profile",titleTooltip:le(ce,{children:["Typing of JSON field values:",ie("pre",{children:JSON.stringify(yn,null,2)})]})}),ie(De.Body,{content:ie(we,{size:"m",ref:i,label:"JSON",value:e,onChange:v,minRows:4,maxRows:4,error:n??void 0})}),ie(De.Footer,{actions:le(ce,{children:[ie(ze,{size:"m",appearance:"primary",label:"Import",onClick:r}),ie(Ee,{onFilesUpload:l,children:ie(_e,{size:"m",appearance:"neutral",label:"Load file",icon:ie(me,{})})})]})})]})})}},Symbol.toStringTag,{value:"Module"}));function Cn(){return ie("svg",{height:"32",width:"32","aria-hidden":"true",viewBox:"0 0 16 16",version:"1.1","data-view-component":"true",fill:"var(--sys-neutral-text-main)",children:ie("path",{d:"M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27-.68 0-1.36.09-2 .27-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8Z"})})}const kn=Ie.div`
  ${de.themeVars.sans.title.m};

  color: ${({color:e})=>e};
  display: grid;
  place-items: center;

  min-height: 48px;
  width: 48px;

  cursor: pointer;
  border-radius: 50%;
  border-width: 8px;
  border-style: solid;
  border-color: ${de.themeVars.sys.neutral.background1Level};

  background-color: ${({backgroundColor:e})=>e};

  &[data-selected] {
    border-radius: 0;
    border-color: ${({backgroundColor:e})=>e};
  }
`;function wn({profileId:e,index:n,isSelected:t,profileNameAbbreviation:o}){const a=Ke[n%Ke.length];return ie(kn,{"data-selected":t||void 0,onClick:()=>Y(e),color:a.font,backgroundColor:a.background,children:0===o.length?n+1:o})}const Sn="https://github.com/cloud-ru-tech/cloudhood",Vn=e=>{const n=e.trim().split(/\s+/);return n.length>1?(n[0].charAt(0)+n[1].charAt(0)).toUpperCase():n[0]?.slice(0,2).toUpperCase()||""},Dn=Ie.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  width: 48px;
`,zn=Ie.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 6px 0;

  overflow-y: auto;

  &::-webkit-scrollbar {
    display: none;
  }

  -ms-overflow-style: none; /* IE and Edge */
  scrollbar-width: none; /* Firefox */
`,En=Ie.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  align-items: center;
  padding: 4px 0;
  justify-content: space-between;
`,_n=Ie.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`,Pn=Sn;function Mn(){const[e,n,t,o,a]=re([ee,ne,te,B,I]);return le(Dn,{children:[ie(zn,{children:a.map((e,n)=>ie(wn,{index:n,isSelected:e.id===t,profileId:e.id,profileNameAbbreviation:Vn(e.name??`Profile ${n+1}`)},e.id.toString()))}),le(En,{children:[ie(ge,{onClick:o,size:"m",icon:ie(ue,{})}),le(_n,{children:[ie(ve,{placement:"right-end",selection:{mode:"single",value:e,onChange:n},items:[{id:oe.Light,content:{option:"Light"},beforeContent:ie(Me,{})},{id:oe.Dark,content:{option:"Dark"},beforeContent:ie(je,{})},{id:oe.System,content:{option:"System"},beforeContent:ie(Re,{})}],children:ie(ge,{size:"m",icon:ie(Pe,{})})}),ie(ge,{onClick:()=>window.open(Pn,"_blank")?.focus(),size:"m",icon:ie(Cn,{})})]})]})]})}const jn=/^[\^_`a-zA-Z\-0-9!#$%&'*+.|~]+$/,Rn=/[^\t\x20-\x7e\x80-\xff]/,An=e=>"string"!=typeof e||0===e.length,On=e=>!An(e)&&jn.test(e),$n=e=>!An(e)&&!Rn.test(e),In=(e,n)=>On(e)&&$n(n),Bn=Ie.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  gap: 4px;

  transform: ${e=>Be.Transform.toString(e.transform)};
  opacity: ${e=>e.isDragging?0:1};
  transition: ${e=>e.transition};

  width: 100%;
`,Hn=Ie.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 4px;
  min-width: 280px;
`,Ln=Ie(ve)`
  width: 228px;
`;function Tn({id:e,name:n,value:t}){const[o,a,r,s]=re([C,k,w,q]),[i,l]=se.useState(!1);return ie(Ln,{open:i,onOpenChange:l,placement:"bottom-end",size:"m",items:[{id:"duplicate-value",content:{option:"Duplicate"},beforeContent:ie(S,{}),onClick:()=>o(e)},{id:"copy-value",content:{option:"Copy"},beforeContent:ie(he,{}),onClick:()=>{a({name:n,value:t}),l(!1)}},{id:"clear-value",content:{option:"Clear Value"},beforeContent:ie(Ae,{}),onClick:()=>r(e)}],children:ie(ge,{size:"s",icon:ie(Ce,{}),disabled:s})})}function qn(e){const{disabled:n,name:t,value:o,id:a}=e,{setNodeRef:r,listeners:s,attributes:i,transition:l,transform:c,isDragging:d}=He({id:a}),{isPaused:u}=re({isPaused:q}),p=On(t),m=$n(o),[f,h]=se.useState(!1),g=e=>n=>{const t=n.clipboardData.getData("text/plain");[E,_].some(e=>t.includes(e))&&(n.preventDefault(),P({id:a,value:t,field:e}))},b=e=>{const n=e.target.selectionStart;" "===e.key&&0===n&&e.preventDefault()},y=n=>t=>{z([{...e,[n]:t}])};return le(Bn,{ref:r,transform:c,transition:l,isDragging:d,children:[le(Hn,{children:[ie(V,{disabled:u,listeners:s,attributes:i}),ie(Oe,{disabled:u,checked:!n,onChange:n=>{z([{...e,disabled:!n}])}}),ie($e,{open:f&&t.length>0&&!p,tip:'Header names may only include Latin characters without spaces and these special symbols: (),/:;<=>?@[]{}")',placement:"top",children:ie(ye,{size:"m",value:t,placeholder:"Header name",onChange:y("name"),onPaste:g("name"),onKeyDown:b,onFocus:()=>h(!0),onBlur:()=>h(!1),showClearButton:!1,disabled:u,validationState:t.length>0&&!p?"error":"default"})})]}),ie($e,{tip:"Incorrect format for header value",placement:"top",open:o.length>0&&!m,children:ie(ye,{size:"m",value:o,placeholder:"Header value",onChange:y("value"),onPaste:g("value"),onKeyDown:b,showClearButton:!1,disabled:u,validationState:o.length>0&&!m?"error":"default"})}),ie(ge,{disabled:u,size:"s",icon:ie(Ae,{}),onClick:()=>D([a])}),ie(Tn,{...e})]})}const Fn=Ie.div`
  display: flex;
  flex-direction: column;

  gap: 8px;
  flex: 1 1 auto;
  align-items: flex-end;
`;function Nn(){const{requestHeaders:e,flattenRequestHeaders:n,activeRequestHeader:t}=re({requestHeaders:ae,flattenRequestHeaders:$,activeRequestHeader:O}),o=Le(Te(Je),Te(Ue));return le(Ne,{modifiers:[A],sensors:o,onDragStart:R,onDragOver:j,onDragEnd:M,children:[ie(Fn,{children:ie(qe,{items:n,children:e.map(e=>ie(qn,{...e},e.id))})}),ie(Fe,{children:(a=t,Boolean(a)?ie(qn,{...t}):null)})]});var a}export{Ge as $,rn as H,pn as L,Nn as R,Mn as S,Ke as p,In as v};
