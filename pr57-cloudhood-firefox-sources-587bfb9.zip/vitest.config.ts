import createConfig from '@cloud-ru/ft-config-vitest';

export default createConfig();
