export const DELIMITER = ':';
export const NEW_ROW = '\n';
