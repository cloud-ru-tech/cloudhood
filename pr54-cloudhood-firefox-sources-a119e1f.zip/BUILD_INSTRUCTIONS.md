# Инструкции по сборке CloudHood для Firefox

## Системные требования

- Node.js версии 18 или выше
- pnpm версии 10.10.0 или выше

## Установка зависимостей

```bash
pnpm install
```

## Сборка расширения

Для сборки расширения для Firefox выполните:

```bash
pnpm build:firefox
```

Собранное расширение будет находиться в папке `dist/firefox/`.

## Дополнительные команды

- `pnpm lint` - проверка кода на соответствие стандартам
- `pnpm test:unit` - запуск юнит-тестов
- `pnpm start:firefox` - запуск в режиме разработки для Firefox
- `pnpm build:chromium` - сборка для Chromium/Chrome

## Структура проекта

- `src/` - исходный код расширения
- `scripts/` - скрипты сборки
- `manifest.firefox.json` - манифест для Firefox
- `manifest.chromium.json` - манифест для Chromium
- `webpack.config.js` - конфигурация Webpack
- `tsconfig.json` - конфигурация TypeScript

## Файлы конфигурации

- `lint-staged.config.js` - конфигурация pre-commit хуков
- `stylelint.config.js` - конфигурация StyleLint
- `vitest.config.ts` - конфигурация тестов

## Примечания

Данный архив содержит полные исходные коды расширения CloudHood.
Все зависимости указаны в package.json и устанавливаются автоматически при выполнении `pnpm install`.

Расширение поддерживает как Firefox, так и Chromium-браузеры.
Используются отдельные манифесты для каждого типа браузера.
