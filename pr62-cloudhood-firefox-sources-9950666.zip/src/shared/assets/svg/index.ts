import { DragIndicatorSVG } from './DragIndicator';
import { EditSVG } from './Edit';
import { FileOpenSVG } from './FileOpen';
import { PauseSVG } from './Pause';
import { PlayArrowSVG } from './PlayArrow';
import { SwitchAccountSVG } from './SwitchAccount';

export { DragIndicatorSVG, EditSVG, FileOpenSVG, PauseSVG, PlayArrowSVG, SwitchAccountSVG };
