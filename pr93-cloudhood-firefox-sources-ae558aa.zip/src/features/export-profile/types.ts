export type OptionProfileExport = {
  id: string;
  name: string;
};
