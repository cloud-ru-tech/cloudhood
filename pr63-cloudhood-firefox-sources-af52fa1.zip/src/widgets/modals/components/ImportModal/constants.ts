export const TOOLTIP_TITLE = 'Typing of JSON field values:';
export const TOOLTIP_JSON_FORMAT = [{ requestHeaders: [{ name: 'string', value: 'string', disabled: 'boolean' }] }];
