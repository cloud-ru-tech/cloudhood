module.exports = {
  extends: '@cloud-ru/ft-config-stylelint',
};
